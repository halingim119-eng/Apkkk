package com.rbxbot.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** 숨겨진 WebView(진짜 크롬 엔진)로 Cloudflare 확인을 통과한 뒤, 그 페이지 안에서 fetch 로 API를 호출 */
object BypassWeb {
    private val main = Handler(Looper.getMainLooper())
    private var wv: WebView? = null
    private var base: String? = null
    private val waits = ConcurrentHashMap<String, CountDownLatch>()
    private val outs = ConcurrentHashMap<String, Pair<Int, String>>()
    private val seq = AtomicInteger()
    private const val UA = "Mozilla/5.0 (Linux; Android 14; SM-S918N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    class Bridge {
        @JavascriptInterface
        fun done(id: String, code: Int, text: String) {
            outs[id] = Pair(code, text)
            waits[id]?.countDown()
        }
    }

    private fun q(s: String) = JSONObject.quote(s)

    @Synchronized
    fun ensure(ctx: Context, b: String): Boolean {
        if (wv != null && base == b) return true
        val app = ctx.applicationContext
        val latch = CountDownLatch(1)
        main.post {
            try {
                wv?.destroy()
                val w = WebView(app)
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA
                w.addJavascriptInterface(Bridge(), "AndroidBridge")
                CookieManager.getInstance().setAcceptCookie(true)
                w.webViewClient = WebViewClient()
                w.loadUrl("$b/")
                wv = w
            } catch (e: Exception) {
                wv = null
            }
            latch.countDown()
        }
        latch.await(10, TimeUnit.SECONDS)
        if (wv == null) return false
        base = null
        try { Thread.sleep(3000) } catch (e: InterruptedException) { return false }
        val end = System.currentTimeMillis() + 50000
        while (System.currentTimeMillis() < end) {
            val (c, t) = fetch("GET", "$b/api/v1/bypass/result/probe", null)
            val blocked = c == 0 || t.contains("Just a moment") ||
                (c == 403 || c == 503) && t.trimStart().startsWith("<")
            if (!blocked) {
                base = b
                return true
            }
            try { Thread.sleep(2500) } catch (e: InterruptedException) { return false }
        }
        return false
    }

    fun fetch(method: String, url: String, body: String?): Pair<Int, String> {
        val w = wv ?: return Pair(0, "WebView 없음")
        val id = "r" + seq.incrementAndGet()
        val latch = CountDownLatch(1)
        waits[id] = latch
        val headers = if (body != null) "{'Accept':'application/json','Content-Type':'application/json'}" else "{'Accept':'application/json'}"
        val opts = StringBuilder("{method:${q(method)},headers:$headers")
        if (body != null) opts.append(",body:${q(body)}")
        opts.append("}")
        val js = "(async()=>{try{const r=await fetch(${q(url)},$opts);const t=await r.text();" +
            "AndroidBridge.done(${q(id)},r.status,t);}catch(e){AndroidBridge.done(${q(id)},0,String(e));}})();"
        main.post { w.evaluateJavascript(js, null) }
        try { latch.await(90, TimeUnit.SECONDS) } catch (e: InterruptedException) { }
        waits.remove(id)
        return outs.remove(id) ?: Pair(0, "시간 초과")
    }
}
