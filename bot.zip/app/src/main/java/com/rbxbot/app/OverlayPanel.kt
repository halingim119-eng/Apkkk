package com.rbxbot.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** 다른 앱 위에 뜨는 드래그 가능한 설정/로그/덤프 창 (접근성 오버레이라 별도 권한 필요 없음) */
class OverlayPanel(private val svc: KakaoAccessibilityService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dm = svc.resources.displayMetrics
    private val h = Handler(Looper.getMainLooper())

    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var body: LinearLayout? = null
    private var content: LinearLayout? = null
    private var actions: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var toggle: Button? = null
    private var statusTv: TextView? = null
    private val tabBtns = ArrayList<Button>()
    private val fields = HashMap<String, View>()
    private var tab = 0
    private var dumpText = "아래 '지금 화면 덤프'를 누르면, 이 창 밑에 떠 있는 앱 화면 구조가 여기에 나와요."

    val isShown: Boolean get() = root != null

    private fun dp(v: Int) = (v * dm.density).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r.toFloat()
        return g
    }

    private fun btn(text: String, bg: Int, onClick: () -> Unit): Button {
        val b = Button(svc)
        b.text = text
        b.textSize = 12f
        b.setTextColor(Color.WHITE)
        b.background = rounded(bg, dp(8))
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.isAllCaps = false
        b.setPadding(dp(10), dp(6), dp(10), dp(6))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun margin(weight: Float): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(if (weight > 0f) 0 else LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, weight)
        p.setMargins(dp(2), dp(3), dp(2), dp(3))
        return p
    }

    fun show() {
        if (root != null) return
        val w = minOf(dm.widthPixels - dp(16), dp(340))
        val r = LinearLayout(svc)
        r.orientation = LinearLayout.VERTICAL
        r.background = rounded(0xF0202026.toInt(), dp(14))
        r.setPadding(dp(8), dp(6), dp(8), dp(8))

        val params = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = Prefs.raw(svc, "px", dp(8).toString()).toIntOrNull() ?: dp(8)
        params.y = Prefs.raw(svc, "py", dp(90).toString()).toIntOrNull() ?: dp(90)
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        lp = params

        // ----- 헤더 (끌어서 이동) + 켜기/끄기 토글 -----
        val header = LinearLayout(svc)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val handle = TextView(svc)
        handle.text = "⠿ 봇"
        handle.setTextColor(Color.WHITE)
        handle.textSize = 15f
        handle.setPadding(dp(8), dp(8), dp(12), dp(8))
        val drag = dragListener()
        handle.setOnTouchListener(drag)
        header.setOnTouchListener(drag)
        val tg = btn("", 0) { toggleBot() }
        toggle = tg
        val minB = btn("▾", 0xFF555560.toInt()) { toggleBody() }
        val closeB = btn("✕", 0xFF555560.toInt()) {
            Prefs.put(svc, "panelOn", "0")
            hide()
        }
        header.addView(handle)
        header.addView(tg, margin(1f))
        header.addView(minB, margin(0f))
        header.addView(closeB, margin(0f))
        r.addView(header)

        val st = TextView(svc)
        st.textSize = 10f
        st.setTextColor(0xFFAAAAAA.toInt())
        st.setPadding(dp(8), 0, dp(8), dp(2))
        statusTv = st
        r.addView(st)

        // ----- 본문 -----
        val b = LinearLayout(svc)
        b.orientation = LinearLayout.VERTICAL
        val tabs = LinearLayout(svc)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabBtns.clear()
        for ((i, name) in listOf("설정", "로그", "덤프").withIndex()) {
            val tb = btn(name, 0) { selectTab(i) }
            tabBtns.add(tb)
            tabs.addView(tb, margin(1f))
        }
        val sv = ScrollView(svc)
        scroll = sv
        val cont = LinearLayout(svc)
        cont.orientation = LinearLayout.VERTICAL
        cont.setPadding(dp(4), dp(4), dp(4), dp(4))
        sv.addView(cont)
        content = cont
        val maxH = minOf((dm.heightPixels * 0.42).toInt(), dp(380))
        val act = LinearLayout(svc)
        act.orientation = LinearLayout.HORIZONTAL
        actions = act
        b.addView(tabs)
        b.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH))
        b.addView(act)
        body = b
        r.addView(b)

        wm.addView(r, params)
        root = r
        styleToggle()
        render()
        h.post(ticker)
    }

    fun hide() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (e: Exception) {
        }
        root = null
        h.removeCallbacksAndMessages(null)
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (root == null) return
            updateStatus()
            h.postDelayed(this, 1500)
        }
    }

    private fun updateStatus() {
        statusTv?.text = "알림 ${if (Status.nls) "✅" else "❌"} ${Status.ago(Status.lastNoti)} · " +
            "카톡화면 ${Status.ago(Status.lastKakaoEvent)} · 메시지 ${Status.ago(Status.lastMsg)}"
    }

    // ---------- 토글 / 탭 ----------

    private fun toggleBot() {
        val on = !Prefs.b(svc, "enabled")
        Prefs.put(svc, "enabled", on.toString())
        L.d(svc, "플로팅 토글: 봇 ${if (on) "켬" else "끔"}")
        styleToggle()
    }

    private fun styleToggle() {
        val on = Prefs.b(svc, "enabled")
        toggle?.text = if (on) "● 봇 켜짐" else "○ 봇 꺼짐"
        toggle?.background = rounded(if (on) 0xFF2E9E5B.toInt() else 0xFFC0392B.toInt(), dp(8))
    }

    private fun toggleBody() {
        val b = body ?: return
        b.visibility = if (b.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        focusable(false)
    }

    private fun selectTab(i: Int) {
        tab = i
        focusable(false)
        render()
    }

    private fun render() {
        val c = content ?: return
        val a = actions ?: return
        c.removeAllViews()
        a.removeAllViews()
        fields.clear()
        when (tab) {
            0 -> renderSettings(c, a)
            1 -> renderLog(c, a)
            else -> renderDump(c, a)
        }
        for ((i, b) in tabBtns.withIndex()) {
            b.background = rounded(if (i == tab) 0xFF3D6FD8.toInt() else 0xFF555560.toInt(), dp(8))
        }
        updateStatus()
    }

    private fun renderSettings(c: LinearLayout, a: LinearLayout) {
        for (f in Prefs.FIELDS) {
            if (f.key == "enabled") continue // 위의 토글이 담당
            if (f.kind == 'b') {
                val sw = Switch(svc)
                sw.text = f.label
                sw.textSize = 13f
                sw.setTextColor(Color.WHITE)
                sw.isChecked = Prefs.b(svc, f.key)
                sw.setOnCheckedChangeListener { _, on -> Prefs.put(svc, f.key, on.toString()) }
                sw.setPadding(0, dp(6), 0, dp(6))
                c.addView(sw)
            } else {
                val tv = TextView(svc)
                tv.text = f.label
                tv.textSize = 11f
                tv.setTextColor(0xFFCCCCCC.toInt())
                tv.setPadding(0, dp(8), 0, dp(2))
                c.addView(tv)
                val et = EditText(svc)
                et.setText(Prefs.s(svc, f.key))
                et.textSize = 13f
                et.setTextColor(Color.WHITE)
                et.setBackgroundColor(0x33FFFFFF)
                et.setPadding(dp(8), dp(6), dp(8), dp(6))
                et.isSingleLine = true
                if (f.kind == 'i') et.inputType = InputType.TYPE_CLASS_NUMBER
                et.imeOptions = EditorInfo.IME_ACTION_DONE
                et.setOnEditorActionListener { v, _, _ ->
                    v.clearFocus()
                    true
                }
                et.setOnTouchListener { v, ev ->
                    if (ev.action == MotionEvent.ACTION_DOWN) {
                        focusable(true)
                        v.postDelayed({
                            v.requestFocus()
                            imm().showSoftInput(v, 0)
                        }, 200)
                    }
                    false
                }
                et.setOnFocusChangeListener { v, has ->
                    if (!has) {
                        imm().hideSoftInputFromWindow(v.windowToken, 0)
                        h.postDelayed({
                            if (fields.values.none { it is EditText && it.hasFocus() }) focusable(false)
                        }, 300)
                    }
                }
                fields[f.key] = et
                c.addView(et)
            }
        }
        a.addView(btn("저장", 0xFF2E9E5B.toInt()) { saveFields() }, margin(1f))
        a.addView(btn("기본값", 0xFF555560.toInt()) {
            Prefs.reset(svc)
            Prefs.put(svc, "panelOn", "1")
            styleToggle()
            render()
        }, margin(1f))
        a.addView(btn("전체화면", 0xFF555560.toInt()) {
            try {
                val i = Intent(svc, SettingsActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                svc.startActivity(i)
            } catch (e: Exception) {
                L.d(svc, "전체화면 설정 열기 실패: $e")
            }
        }, margin(1f))
    }

    private fun saveFields() {
        for ((k, v) in fields) {
            if (v is EditText) Prefs.put(svc, k, v.text.toString())
        }
        focusable(false)
        Toast.makeText(svc, "저장했어요", Toast.LENGTH_SHORT).show()
    }

    private fun renderLog(c: LinearLayout, a: LinearLayout) {
        val tv = TextView(svc)
        tv.textSize = 10f
        tv.setTextColor(0xFFDDDDDD.toInt())
        tv.text = L.read(svc, 150)
        c.addView(tv)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
        a.addView(btn("새로고침", 0xFF555560.toInt()) { render() }, margin(1f))
        a.addView(btn("복사", 0xFF3D6FD8.toInt()) { copy(L.read(svc, 400)) }, margin(1f))
        a.addView(btn("지우기", 0xFF555560.toInt()) {
            L.clear(svc)
            render()
        }, margin(1f))
    }

    private fun renderDump(c: LinearLayout, a: LinearLayout) {
        val tv = TextView(svc)
        tv.textSize = 10f
        tv.setTextColor(0xFFDDDDDD.toInt())
        tv.text = dumpText
        c.addView(tv)
        a.addView(btn("지금 화면 덤프", 0xFF2E9E5B.toInt()) {
            dumpText = "덤프 중…"
            render()
            Thread {
                val s = try { svc.dumpScreen() } catch (e: Exception) { "덤프 오류: $e" }
                h.post {
                    dumpText = s
                    if (root != null && tab == 2) render()
                }
            }.start()
        }, margin(1f))
        a.addView(btn("복사", 0xFF3D6FD8.toInt()) { copy(dumpText) }, margin(1f))
    }

    private fun copy(s: String) {
        val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("bot", s))
        Toast.makeText(svc, "복사했어요", Toast.LENGTH_SHORT).show()
    }

    // ---------- 키보드 입력을 위해 창 포커스를 잠깐 켰다 끔 ----------

    private fun imm() = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun focusable(on: Boolean) {
        val r = root ?: return
        val p = lp ?: return
        val has = (p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (on == has) return
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try {
            wm.updateViewLayout(r, p)
        } catch (e: Exception) {
        }
    }

    private fun dragListener() = object : View.OnTouchListener {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val p = lp ?: return false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x
                    sy = p.y
                    tx = e.rawX
                    ty = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - tx).toInt()
                    p.y = sy + (e.rawY - ty).toInt()
                    val r = root
                    if (r != null) {
                        try { wm.updateViewLayout(r, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.put(svc, "px", p.x.toString())
                    Prefs.put(svc, "py", p.y.toString())
                }
            }
            return true
        }
    }
}
