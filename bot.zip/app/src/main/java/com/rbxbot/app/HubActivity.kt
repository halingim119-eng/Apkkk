package com.rbxbot.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class LinkItem(val url: String, val date: String = "") {
    /** 0 대기 / 1 진행 / 2 완료 / 3 실패 */
    @Volatile var status = 0
    @Volatile var out = ""
    @Volatile var err = ""
}

class Game(val name: String) {
    @Volatile var phase = "대기"
    val links = CopyOnWriteArrayList<LinkItem>()
    /** 이미 본 영상 / 이미 찾은 링크 (다음 회차에 같은 걸 또 안 쓰려고). 게임 하나는 한 스레드만 만짐 */
    val seen = HashSet<String>()
    val known = HashSet<String>()
}

/** 검색 + 링크 찾기 + 바이패스(10개씩 동시) 를 한 화면에서 */
class HubActivity : Activity() {
    private val BG = Color.parseColor("#000000")
    private val SURF = Color.parseColor("#101010")
    private val LINE = Color.parseColor("#262626")
    private val TEXT = Color.parseColor("#EDEDED")
    private val SUB = Color.parseColor("#8A8A8A")
    private val GREEN = Color.parseColor("#4ADE80")
    private val RED = Color.parseColor("#F87171")
    private val AMBER = Color.parseColor("#FBBF24")

    private val main = Handler(Looper.getMainLooper())
    private val games = CopyOnWriteArrayList<Game>()
    @Volatile private var cancel = false
    @Volatile private var renderQueued = false
    private var pool: ExecutorService? = null
    private var gamePool: ExecutorService? = null
    private val expanded = HashSet<String>()

    private lateinit var input: EditText
    private lateinit var autoSw: Switch
    private lateinit var summary: TextView
    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(if (primary) BG else TEXT)
        b.background = box(if (primary) TEXT else SURF, 10, if (primary) 0 else LINE)
        b.stateListAnimator = null
        b.setPadding(dp(12), dp(10), dp(12), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg views: android.view.View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        return r
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(30), dp(18), dp(40))
        sv.addView(col)

        col.addView(tv("Hub", 28f, TEXT, true))
        col.addView(tv("검색 · 링크 · 바이패스", 13f, SUB))

        val l1 = tv("검색어  (게임마다 한 줄)", 12f, SUB)
        l1.setPadding(0, dp(22), 0, dp(6))
        col.addView(l1)

        input = EditText(this)
        input.hint = "Blox Fruits\nPet Simulator 99\nDoors"
        input.setHintTextColor(Color.parseColor("#4A4A4A"))
        input.setTextColor(TEXT)
        input.textSize = 15f
        input.minLines = 4
        input.gravity = Gravity.TOP
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.background = box(SURF, 12, LINE)
        input.setPadding(dp(14), dp(12), dp(14), dp(12))
        col.addView(input)

        val ar = LinearLayout(this)
        ar.orientation = LinearLayout.HORIZONTAL
        ar.gravity = Gravity.CENTER_VERTICAL
        ar.setPadding(dp(2), dp(12), dp(2), dp(4))
        val at = tv("찾는 즉시 자동 바이패스 (10개씩 동시)", 14f, TEXT)
        ar.addView(at, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        autoSw = Switch(this)
        autoSw.isChecked = true
        ar.addView(autoSw)
        col.addView(ar)

        col.addView(row(btn("검색 시작", true) { start() }, btn("중지", false) { stopAll(true) }))

        summary = tv("", 13f, SUB)
        summary.setPadding(dp(2), dp(14), dp(2), dp(2))
        col.addView(summary)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)

        val tools = tv("도구", 12f, SUB)
        tools.setPadding(0, dp(24), 0, dp(6))
        col.addView(tools)
        col.addView(row(btn("바이패스 실행", false) { runBypassPending() }, btn("결과 복사", false) { copyResult() }))
        col.addView(row(btn("Pastefy로 올리기", false) { uploadResult() }, btn("설정", false) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }))
        col.addView(row(btn("카톡 봇 연결·권한", false) {
            startActivity(Intent(this, MainActivity::class.java))
        }, btn("로그", false) {
            startActivity(Intent(this, LogActivity::class.java))
        }))

        setContentView(sv)
        draw()
    }

    // ---------- 동작 ----------

    private fun start() {
        val names = input.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (names.isEmpty()) {
            Toast.makeText(this, "검색어를 한 줄에 하나씩 적어주세요", Toast.LENGTH_SHORT).show()
            return
        }
        stopAll(false)
        cancel = false
        games.clear()
        names.forEach { games.add(Game(it)) }
        val p = Executors.newFixedThreadPool(10)
        pool = p
        val auto = autoSw.isChecked
        val ctx = applicationContext
        val gp = Executors.newFixedThreadPool(Prefs.i(ctx, "parGames2").coerceIn(1, 50))
        gamePool = gp
        draw()
        for (g in games) {
            gp.execute {
                try {
                    processGame(g, ctx, p, auto)
                } catch (e: InterruptedException) {
                    g.phase = "중지됨"
                    render()
                } catch (e: Exception) {
                    g.phase = "오류: ${e.message}"
                    render()
                }
            }
        }
        gp.shutdown()
    }

    private fun doneCount(g: Game) = g.links.filter { it.status == 2 }.map { it.out }.distinct().size

    /** 게임 하나: 영상 100개+ 검색 → 링크 찾기 → (자동이면) 바이패스. 링크가 없어도 다시 시작하지 않음 */
    private fun processGame(g: Game, ctx: Context, bp: ExecutorService, auto: Boolean) {
        g.phase = "영상 찾는 중"
        render()
        val vids = Scraper.searchAll(ctx, g.name)
        if (cancel) return
        if (vids.isEmpty()) {
            val e = Api.lastError
            g.phase = if (e.isNotEmpty()) "영상 없음 · $e" else "영상 없음"
            render()
            return
        }
        g.phase = "링크 찾는 중 (영상 ${vids.size}개)"
        render()
        val st = java.util.concurrent.atomic.AtomicIntegerArray(3)
        val hits = Scraper.collect(ctx, vids, st)
        val diag = "영상 ${vids.size} · 정보 ${st.get(0)} · script조건 ${st.get(1)} · 댓글확인 ${st.get(2)}"
        L.d(ctx, "[${g.name}] $diag / 링크 영상 ${hits.size}개 / 오류='${Api.lastError}'")
        val dates = Scraper.linkDates(hits)
        val items = Scraper.uniqueLinks(hits).map { LinkItem(it, dates[it].orEmpty()) }
        g.links.addAll(items)
        g.phase = if (items.isEmpty()) "링크 없음 ($diag)" + (if (st.get(0) == 0 && Api.lastError.isNotEmpty()) "\n${Api.lastError}" else "") else "링크 ${items.size}개 (영상 ${vids.size}개)"
        render()
        if (auto && !cancel) items.forEach { submit(bp, ctx, it) }
    }

    private fun stopAll(toast: Boolean) {
        cancel = true
        try { pool?.shutdownNow() } catch (e: Exception) { }
        try { gamePool?.shutdownNow() } catch (e: Exception) { }
        pool = null
        gamePool = null
        for (g in games) for (li in g.links) if (li.status == 1) li.status = 0
        if (toast) Toast.makeText(this, "중지했어요", Toast.LENGTH_SHORT).show()
        draw()
    }

    private fun runBypassPending() {
        var p = pool
        if (p == null || p.isShutdown) {
            p = Executors.newFixedThreadPool(10)
            pool = p
        }
        cancel = false
        val ctx = applicationContext
        var n = 0
        for (g in games) for (li in g.links) {
            if (li.status == 0 || li.status == 3) {
                submit(p!!, ctx, li)
                n++
            }
        }
        Toast.makeText(this, if (n == 0) "바이패스할 링크가 없어요" else "${n}개 바이패스 시작 (10개씩)", Toast.LENGTH_SHORT).show()
        draw()
    }

    private fun submit(p: ExecutorService, ctx: Context, li: LinkItem) {
        if (li.status == 1 || li.status == 2) return
        li.status = 1
        li.err = ""
        try {
            p.execute {
                if (cancel) {
                    li.status = 0
                } else {
                    render()
                    val (out, err) = Api.bypassChain(ctx, li.url)
                    if (out != null) {
                        li.out = out
                        li.status = 2
                    } else {
                        li.err = err ?: "실패"
                        li.status = 3
                    }
                }
                render()
            }
        } catch (e: Exception) {
            li.status = 0
        }
    }

    // ---------- 결과 ----------

    private fun resultText(prefix: String): String {
        val sb = StringBuilder()
        for (g in games) {
            val done = g.links.filter { it.status == 2 }.distinctBy { it.out }
            if (done.isEmpty()) continue
            sb.append(prefix).append("[").append(g.name).append("]\n")
            done.forEachIndexed { i, li ->
                sb.append(prefix).append("[").append(i + 1).append("] ").append(li.out)
                if (li.date.isNotEmpty()) sb.append(" (").append(li.date).append(")")
                sb.append('\n')
            }
            sb.append(if (prefix.isEmpty()) "\n" else "|\n")
        }
        return sb.toString().trim()
    }

    private fun clip(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("hub", text))
    }

    private fun copyResult() {
        val t = resultText("")
        if (t.isEmpty()) {
            Toast.makeText(this, "완료된 링크가 아직 없어요", Toast.LENGTH_SHORT).show()
            return
        }
        clip(t)
        Toast.makeText(this, "복사했어요", Toast.LENGTH_SHORT).show()
    }

    private fun uploadResult() {
        val t = resultText("| ")
        if (t.isEmpty()) {
            Toast.makeText(this, "완료된 링크가 아직 없어요", Toast.LENGTH_SHORT).show()
            return
        }
        val title = "| " + games.joinToString(", ") { it.name } + " 스크립트&링크"
        val key = Prefs.s(this, "pastefyKey").trim()
        Toast.makeText(this, "올리는 중…", Toast.LENGTH_SHORT).show()
        Thread {
            val raw = Api.paste(key, title, t)
            main.post {
                if (raw != null) {
                    clip(raw)
                    Toast.makeText(this, "올렸어요 (링크 복사됨)\n$raw", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Pastefy 업로드 실패", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- 화면 ----------

    private fun render() {
        if (renderQueued) return
        renderQueued = true
        main.postDelayed({
            renderQueued = false
            draw()
        }, if (games.size > 20) 1200L else 400L)
    }

    private fun draw() {
        list.removeAllViews()
        var total = 0
        var done = 0
        var run = 0
        var fail = 0
        for (g in games) {
            total += g.links.size
            val d = g.links.count { it.status == 2 }
            done += d
            run += g.links.count { it.status == 1 }
            fail += g.links.count { it.status == 3 }

            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = box(SURF, 14, LINE)
            card.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(12)

            val open = games.size <= 3 || expanded.contains(g.name)
            val head = tv(g.name, 16f, TEXT, true)
            card.addView(head)
            val sub = (if (g.links.isEmpty()) g.phase else "${g.phase} · 완료 $d/${g.links.size}") +
                (if (!open && g.links.isNotEmpty()) "  ·  탭해서 펼치기" else "")
            val st = tv(sub, 12f, SUB)
            st.setPadding(0, dp(2), 0, dp(6))
            card.addView(st)
            if (games.size > 3) {
                card.setOnClickListener {
                    if (!expanded.add(g.name)) expanded.remove(g.name)
                    draw()
                }
            }

            val cap = 80
            if (open) for ((i, li) in g.links.withIndex()) {
                if (i >= cap) {
                    card.addView(tv("… 외 ${g.links.size - cap}개 (복사/업로드에는 모두 포함)", 12f, SUB))
                    break
                }
                card.addView(linkRow(i + 1, li))
            }
            list.addView(card, lp)
        }
        summary.text = if (games.isEmpty()) "" else "게임 ${games.size}  ·  링크 $total  ·  완료 $done  ·  진행 $run  ·  실패 $fail"
    }

    private fun linkRow(n: Int, li: LinkItem): TextView {
        val t = TextView(this)
        t.textSize = 12f
        t.setTextColor(SUB)
        t.setPadding(0, dp(3), 0, dp(3))
        t.setTextIsSelectable(true)
        val (mark, color) = when (li.status) {
            2 -> Pair("✓", GREEN)
            1 -> Pair("…", AMBER)
            3 -> Pair("✕", RED)
            else -> Pair("·", SUB)
        }
        val body = when (li.status) {
            2 -> li.out
            3 -> li.url + "\n    " + li.err.take(120)
            else -> li.url
        }
        val sb = SpannableStringBuilder("$mark ")
        sb.setSpan(ForegroundColorSpan(color), 0, mark.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val start = sb.length
        sb.append("[$n] ").append(body)
        sb.setSpan(ForegroundColorSpan(if (li.status == 2) TEXT else SUB), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (li.date.isNotEmpty()) {
            val ds = sb.length
            sb.append("  (").append(li.date).append(")")
            sb.setSpan(ForegroundColorSpan(SUB), ds, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        t.text = sb
        return t
    }
}
