package com.rbxbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** API가 주는 SVG 배너를 WebView로 그려서 PNG 파일로 만듦 (카톡은 SVG를 사진으로 못 보내서) */
object BannerRenderer {
    fun render(ctx: Context, svg: ByteArray): File? {
        val app = ctx.applicationContext
        val text = String(svg, Charsets.UTF_8).replace(Regex("<\\?xml[^>]*\\?>"), "")
        val vb = Regex("viewBox=\"\\s*[-\\d.]+[ ,]+[-\\d.]+[ ,]+([\\d.]+)[ ,]+([\\d.]+)\"").find(text)
        val vw = vb?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        val vh = vb?.groupValues?.get(2)?.toDoubleOrNull() ?: 0.0
        val ratio = if (vw > 0 && vh > 0) vh / vw else 0.5
        val w = 1200
        val h = (w * ratio).toInt().coerceIn(200, 3000)
        val html = "<html><head><style>html,body{margin:0;padding:0;background:#fff}" +
            "svg{display:block;width:100vw;height:100vh}</style></head><body>$text</body></html>"

        val latch = CountDownLatch(1)
        var out: File? = null
        val main = Handler(Looper.getMainLooper())
        main.post {
            try {
                val wv = WebView(app)
                wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                wv.measure(
                    View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
                )
                wv.layout(0, 0, w, h)
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        main.postDelayed({
                            try {
                                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                view.draw(Canvas(bmp))
                                if (!isBlank(bmp)) {
                                    val dir = File(app.cacheDir, "share")
                                    dir.mkdirs()
                                    val f = File(dir, "banner.png")
                                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                    out = f
                                }
                            } catch (e: Exception) {
                                // 실패하면 null
                            }
                            try { view.destroy() } catch (e: Exception) { }
                            latch.countDown()
                        }, 3000)
                    }
                }
                wv.loadDataWithBaseURL("https://tubeshelf.local/", html, "text/html", "utf-8", null)
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        latch.await(30, TimeUnit.SECONDS)
        return out
    }

    private fun isBlank(b: Bitmap): Boolean {
        for (x in 0 until 20) for (y in 0 until 10) {
            val p = b.getPixel(x * (b.width - 1) / 19, y * (b.height - 1) / 9)
            if (p != Color.WHITE) return false
        }
        return true
    }
}
