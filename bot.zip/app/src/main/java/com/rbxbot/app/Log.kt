package com.rbxbot.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 앱 안에서 볼 수 있는 로그 (메인 화면 -> 로그 보기) */
object L {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val last = HashMap<String, Long>()

    private fun file(c: Context) = File(c.applicationContext.filesDir, "log.txt")

    fun cut(s: String?, n: Int = 40): String {
        val t = (s ?: "").replace("\n", "⏎")
        return if (t.length > n) t.substring(0, n) + "…" else t
    }

    @Synchronized
    fun d(c: Context, msg: String) {
        Log.d("RBXBOT", msg)
        try {
            val f = file(c)
            if (f.exists() && f.length() > 200_000) {
                val lines = f.readLines().takeLast(600)
                f.writeText(lines.joinToString("\n") + "\n")
            }
            f.appendText(fmt.format(Date()) + " " + msg.replace("\n", "⏎") + "\n")
        } catch (e: Exception) {
        }
    }

    /** 같은 key는 ms 안에 한 번만 기록 */
    @Synchronized
    fun rl(c: Context, key: String, ms: Long, msg: String) {
        val now = System.currentTimeMillis()
        val l = last[key]
        if (l != null && now - l < ms) return
        last[key] = now
        d(c, msg)
    }

    @Synchronized
    fun read(c: Context, n: Int = 400): String {
        return try {
            val f = file(c)
            if (!f.exists()) "(로그 없음)" else f.readLines().takeLast(n).joinToString("\n")
        } catch (e: Exception) {
            "(로그 읽기 실패 $e)"
        }
    }

    @Synchronized
    fun clear(c: Context) {
        try { file(c).delete() } catch (e: Exception) { }
    }
}
