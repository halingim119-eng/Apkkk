package com.rbxbot.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class LogActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var sv: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "봇 로그"
        val pad = (8 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.textSize = 12f
            b.setOnClickListener { onClick() }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        btn("새로고침") { refresh() }
        btn("복사") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", L.read(this)))
            Toast.makeText(this, "복사했어요", Toast.LENGTH_SHORT).show()
        }
        btn("지우기") {
            L.clear(this)
            refresh()
        }
        root.addView(row)

        tv = TextView(this)
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        sv = ScrollView(this)
        sv.addView(tv)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        tv.text = L.read(this)
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }
}
