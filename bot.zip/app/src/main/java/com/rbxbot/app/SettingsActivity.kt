package com.rbxbot.app

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private val views = HashMap<String, View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "봇 설정"
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)

        for (f in Prefs.FIELDS) {
            if (f.kind == 'b') {
                val sw = Switch(this)
                sw.text = f.label
                sw.isChecked = Prefs.b(this, f.key)
                sw.setPadding(0, pad, 0, 0)
                views[f.key] = sw
                box.addView(sw)
            } else {
                val tv = TextView(this)
                tv.text = f.label
                tv.setPadding(0, pad, 0, 0)
                box.addView(tv)
                val et = EditText(this)
                et.setText(Prefs.s(this, f.key))
                if (f.kind == 'i') et.inputType = InputType.TYPE_CLASS_NUMBER
                views[f.key] = et
                box.addView(et)
            }
        }

        val save = Button(this)
        save.text = "저장"
        save.setOnClickListener {
            for (f in Prefs.FIELDS) {
                val v = views[f.key]
                val value = if (v is Switch) v.isChecked.toString() else (v as EditText).text.toString()
                Prefs.put(this, f.key, value)
            }
            Toast.makeText(this, "저장했어요", Toast.LENGTH_SHORT).show()
            finish()
        }
        box.addView(save)

        val reset = Button(this)
        reset.text = "기본값으로 되돌리기"
        reset.setOnClickListener {
            Prefs.reset(this)
            Toast.makeText(this, "기본값으로 되돌렸어요", Toast.LENGTH_SHORT).show()
            recreate()
        }
        box.addView(reset)

        val sv = ScrollView(this)
        sv.addView(box)
        setContentView(sv)
    }
}
