package com.rbxbot.app

import android.content.Context

data class Field(val key: String, val label: String, val kind: Char, val def: String)

object Prefs {
    // kind: 's' 글자, 'i' 숫자, 'b' 스위치
    val FIELDS = listOf(
        Field("enabled", "봇 켜기", 'b', "true"),
        Field("useNoti", "알림으로 메시지 감지", 'b', "true"),
        Field("useAcc", "화면 읽기로 감지 (카톡 방 안에 있어도 동작)", 'b', "true"),
        Field("verbose", "자세한 로그 (다른 앱 알림도 기록)", 'b', "true"),
        Field("trigger", "검색 명령어", 's', "!RSS"),
        Field("settingsCmd", "설정창 여는 명령어", 's', "/설정"),
        Field("yes", "확인 응답 단어 (쉼표로 구분)", 's', "응,네"),
        Field("waitSec", "응/네 기다리는 시간 (초)", 'i', "120"),
        Field("maxVideos", "최대 영상 수", 'i', "150"),
        Field("expand", "확장 검색어 (쉼표로 구분, 영상 수 채우려고 검색어 뒤에 붙임. 비우면 원래 검색어만)", 's', "script,roblox script,ui script,gui,hub,pastebin"),
        Field("keyword", "스크립트 감지 단어 (쉼표로 구분)", 's', "script"),
        Field("ownerOnly", "채널 주인 댓글만 검사 (끄면 모든 댓글 검사)", 'b', "true"),
        Field("exclude", "제외할 링크 (쉼표로 구분, 글자가 들어있으면 제외)", 's', "discord.gg,discord.com,discordapp.com"),
        Field("threads", "동시에 검사할 영상 수", 'i', "6"),
        Field("includeInfo", "파일에 영상별 정보도 포함", 'b', "true")
    )

    private fun sp(c: Context) = c.getSharedPreferences("bot", Context.MODE_PRIVATE)
    private fun def(k: String) = FIELDS.first { it.key == k }.def

    fun s(c: Context, k: String): String = sp(c).getString(k, null) ?: def(k)
    fun i(c: Context, k: String): Int = s(c, k).trim().toIntOrNull() ?: def(k).toInt()
    fun b(c: Context, k: String): Boolean = s(c, k) == "true"
    fun list(c: Context, k: String): List<String> =
        s(c, k).split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun raw(c: Context, k: String, d: String): String = sp(c).getString(k, null) ?: d
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun reset(c: Context) = sp(c).edit().clear().apply()
}
