package com.rbxbot.app

import android.app.Notification
import android.app.RemoteInput
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object Kakao {
    /** 방 이름 -> 알림의 답장 액션 (알림이 왔던 방에는 화면 없이도 답장 가능) */
    val actions = ConcurrentHashMap<String, Notification.Action>()

    /** 글자 보내기. 방 안에 있으면 화면(접근성)으로, 아니면 알림 답장으로 */
    fun sendText(ctx: Context, room: String, text: String, src: String): Boolean {
        val acc = KakaoAccessibilityService.inst
        if (acc != null && acc.canSendHere(room, src == "acc") && acc.inRoomSend(text)) return true
        val a = actions[room] ?: return false
        val ris = a.remoteInputs ?: return false
        return try {
            val intent = Intent()
            val b = Bundle()
            for (ri in ris) b.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(ris, intent, b)
            a.actionIntent.send(ctx, 0, intent)
            Thread.sleep(700)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun sendImage(ctx: Context, room: String, f: File, src: String): Boolean = share(ctx, room, f, "image/png")

    fun sendFile(ctx: Context, room: String, f: File, src: String): Boolean = share(ctx, room, f, "text/plain")

    /** 카톡 공유 화면을 열고, 접근성으로 방을 골라서 보냄 */
    private fun share(ctx: Context, room: String, f: File, mime: String): Boolean {
        return try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = mime
            i.setPackage(KAKAO)
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.clipData = ClipData.newRawUri("f", uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            val acc = KakaoAccessibilityService.inst
            if (acc != null) acc.autoPick(room) else true
        } catch (e: Exception) {
            false
        }
    }
}
