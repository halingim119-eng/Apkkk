package com.rbxbot.app

import android.app.Notification
import android.app.RemoteInput
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object Kakao {
    /** 방 이름 -> 알림의 답장 액션 */
    val actions = ConcurrentHashMap<String, Notification.Action>()

    private fun findAction(room: String): Notification.Action? {
        actions[room]?.let { return it }
        if (room.isEmpty()) return null
        return actions.entries.firstOrNull { it.key.isNotEmpty() && (it.key.contains(room) || room.contains(it.key)) }?.value
    }

    fun sendText(ctx: Context, room: String, text: String, src: String): Boolean {
        val acc = KakaoAccessibilityService.inst
        if (acc != null) {
            val can = acc.canSendHere(room, src != "noti")
            L.d(ctx, "보내기 시도: 화면입력 가능=$can 방='${L.cut(room)}' 내용='${L.cut(text, 25)}'")
            if (can && acc.inRoomSend(text)) {
                L.d(ctx, "→ 화면 입력으로 전송함")
                return true
            }
        }
        val a = findAction(room)
        if (a == null) {
            L.d(ctx, "→ 보내기 실패: 이 방의 알림 답장 정보가 없어요 (저장된 방: ${actions.keys.map { L.cut(it, 15) }})")
            return false
        }
        val ris = a.remoteInputs
        if (ris == null) {
            L.d(ctx, "→ 보내기 실패: 답장 입력칸 없음")
            return false
        }
        return try {
            val intent = Intent()
            val b = Bundle()
            for (ri in ris) b.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(ris, intent, b)
            a.actionIntent.send(ctx, 0, intent)
            Thread.sleep(700)
            L.d(ctx, "→ 알림 답장으로 전송함")
            true
        } catch (e: Exception) {
            L.d(ctx, "→ 알림 답장 실패: $e")
            false
        }
    }

    fun sendImage(ctx: Context, room: String, f: File, src: String): Boolean = share(ctx, room, f, "image/png")

    fun sendFile(ctx: Context, room: String, f: File, src: String): Boolean = share(ctx, room, f, "*/*")

    private fun share(ctx: Context, room: String, f: File, mime: String): Boolean {
        return try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = mime
            i.setPackage(KAKAO)
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.clipData = ClipData.newRawUri("f", uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            val acc = KakaoAccessibilityService.inst
            val ok = if (acc != null) acc.autoPick(room) else true
            L.d(ctx, "공유($mime) 결과=$ok 접근성=${acc != null}")
            ok
        } catch (e: Exception) {
            L.d(ctx, "공유 실패: $e")
            false
        }
    }
}
