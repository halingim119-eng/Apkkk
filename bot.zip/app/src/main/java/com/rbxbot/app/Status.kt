package com.rbxbot.app

/** 플로팅 UI 상태줄에 보여줄 진단 정보 */
object Status {
    @Volatile var nls = false
    @Volatile var lastKakaoEvent = 0L
    @Volatile var lastNoti = 0L
    @Volatile var lastMsg = 0L

    fun ago(t: Long): String = if (t == 0L) "없음" else "${(System.currentTimeMillis() - t) / 1000}초 전"
}
