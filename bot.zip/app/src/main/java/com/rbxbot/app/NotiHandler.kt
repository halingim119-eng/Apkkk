package com.rbxbot.app

import android.app.Notification
import android.content.Context
import android.os.Bundle

/** 알림 리스너 / 접근성 알림 이벤트 둘 다 여기로 들어옴 */
object NotiHandler {
    fun handle(ctx: Context, n: Notification, src: String, fallbackText: String? = null) {
        val ex = n.extras
        val title = ex?.getCharSequence("android.title")?.toString()
        val sub = ex?.getCharSequence("android.subText")?.toString()
        var text = ex?.getCharSequence("android.text")?.toString()
        Status.lastNoti = System.currentTimeMillis()
        L.d(ctx, "카톡 알림[$src] title='${L.cut(title)}' sub='${L.cut(sub)}' text='${L.cut(text, 60)}' flags=${n.flags} 답장액션=${n.actions?.size ?: 0}")

        if (!Prefs.b(ctx, "enabled") || !Prefs.b(ctx, "useNoti")) {
            L.d(ctx, "→ 설정에서 꺼져 있어서 무시")
            return
        }
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) {
            L.d(ctx, "→ 묶음 알림(요약)이라 무시")
            return
        }

        @Suppress("DEPRECATION")
        val msgs = ex?.getParcelableArray("android.messages")
        val last = (msgs?.lastOrNull() as? Bundle)?.getCharSequence("text")?.toString()
        if (!last.isNullOrBlank()) text = last
        if (text.isNullOrBlank()) text = ex?.getCharSequence("android.bigText")?.toString()
        if (text.isNullOrBlank()) text = ex?.getCharSequenceArray("android.textLines")?.lastOrNull()?.toString()
        if (text.isNullOrBlank()) text = fallbackText
        if (text.isNullOrBlank()) {
            L.d(ctx, "→ 본문을 못 찾아서 무시")
            return
        }

        val room = if (!sub.isNullOrBlank()) sub else (title ?: "")
        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        if (act != null) Kakao.actions[room] = act

        BotEngine.onMessage(ctx.applicationContext, room, text, "noti")
    }
}
