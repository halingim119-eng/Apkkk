package com.rbxbot.app

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class KakaoNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        Status.nls = true
        L.d(this, "알림 리스너 연결됨")
    }

    override fun onListenerDisconnected() {
        Status.nls = false
        L.d(this, "알림 리스너 연결 끊김 → 다시 연결 시도")
        try {
            requestRebind(ComponentName(this, KakaoNotificationService::class.java))
        } catch (e: Exception) {
            L.d(this, "재연결 실패 $e")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            if (sbn.packageName != KAKAO) {
                if (Prefs.b(this, "verbose")) L.rl(this, "np_" + sbn.packageName, 4000, "알림(다른 앱) ${sbn.packageName}")
                return
            }
            val n = sbn.notification ?: return
            NotiHandler.handle(applicationContext, n, "listener")
        } catch (e: Exception) {
            L.d(this, "알림 처리 오류: $e")
        }
    }
}
