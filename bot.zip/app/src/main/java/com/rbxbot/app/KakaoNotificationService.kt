package com.rbxbot.app

import android.app.Notification
import android.content.ComponentName
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class KakaoNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        L.d(this, "알림 리스너 연결됨")
    }

    override fun onListenerDisconnected() {
        L.d(this, "알림 리스너 연결 끊김 → 다시 연결 시도")
        try {
            requestRebind(ComponentName(this, KakaoNotificationService::class.java))
        } catch (e: Exception) {
            L.d(this, "재연결 실패 $e")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Exception) {
            L.d(this, "알림 처리 오류: $e")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName != KAKAO) {
            if (Prefs.b(this, "verbose")) L.rl(this, "np_" + sbn.packageName, 4000, "알림(다른 앱) ${sbn.packageName}")
            return
        }
        val n = sbn.notification ?: return
        val ex = n.extras
        val title = ex.getCharSequence("android.title")?.toString()
        val sub = ex.getCharSequence("android.subText")?.toString()
        var text = ex.getCharSequence("android.text")?.toString()
        L.d(this, "카톡 알림 title='${L.cut(title)}' sub='${L.cut(sub)}' text='${L.cut(text, 60)}' flags=${n.flags} 답장액션=${n.actions?.size ?: 0}")

        if (!Prefs.b(this, "enabled") || !Prefs.b(this, "useNoti")) {
            L.d(this, "→ 설정에서 꺼져 있어서 무시")
            return
        }
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) {
            L.d(this, "→ 묶음 알림(요약)이라 무시")
            return
        }

        @Suppress("DEPRECATION")
        val msgs = ex.getParcelableArray("android.messages")
        val last = (msgs?.lastOrNull() as? Bundle)?.getCharSequence("text")?.toString()
        if (!last.isNullOrBlank()) text = last
        if (text.isNullOrBlank()) text = ex.getCharSequence("android.bigText")?.toString()
        if (text.isNullOrBlank()) text = ex.getCharSequenceArray("android.textLines")?.lastOrNull()?.toString()
        if (text.isNullOrBlank()) {
            L.d(this, "→ 본문을 못 찾아서 무시")
            return
        }

        val room = if (!sub.isNullOrBlank()) sub else (title ?: "")
        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        if (act != null) Kakao.actions[room] = act

        BotEngine.onMessage(applicationContext, room, text, "noti")
    }
}
