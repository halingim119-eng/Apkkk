package com.rbxbot.app

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class KakaoNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName != KAKAO) return
        if (!Prefs.b(this, "enabled") || !Prefs.b(this, "useNoti")) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val ex = n.extras ?: return
        val title = ex.getCharSequence("android.title")?.toString() ?: return
        val sub = ex.getCharSequence("android.subText")?.toString()
        val room = if (!sub.isNullOrBlank()) sub else title

        var text = ex.getCharSequence("android.text")?.toString()
        @Suppress("DEPRECATION")
        val msgs = ex.getParcelableArray("android.messages")
        val last = (msgs?.lastOrNull() as? Bundle)?.getCharSequence("text")?.toString()
        if (!last.isNullOrBlank()) text = last
        if (text.isNullOrBlank()) return

        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        if (act != null) Kakao.actions[room] = act

        BotEngine.onMessage(applicationContext, room, text, "noti")
    }
}
