package com.rbxbot.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)

        status = TextView(this)
        status.textSize = 16f
        box.addView(status)

        fun btn(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            box.addView(b)
        }
        btn("1. 알림 접근 허용") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("2. 접근성 허용") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("▶ 플로팅 UI 켜기/끄기 (다른 앱 위에 뜸)") {
            val s = KakaoAccessibilityService.inst
            if (s == null) {
                Toast.makeText(this, "접근성을 먼저 켜세요 (실제 연결이 ✅여야 해요)", Toast.LENGTH_LONG).show()
            } else {
                s.togglePanel()
            }
        }
        btn("앱 정보 (제한된 설정 허용할 때)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        btn("설정 열기 (전체화면)") { startActivity(Intent(this, SettingsActivity::class.java)) }
        btn("로그 보기") { startActivity(Intent(this, LogActivity::class.java)) }

        val sv = ScrollView(this)
        sv.addView(box)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val noti = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        val accOn = KakaoAccessibilityService.inst != null
        fun m(b: Boolean) = if (b) "✅" else "❌"
        status.text = "알림 접근 허용: ${m(noti)} (실제 연결: ${m(Status.nls)})\n" +
            "접근성 허용: ${m(acc)} (실제 연결: ${m(accOn)})\n\n" +
            "카톡 방에서 ${Prefs.s(this, "settingsCmd")} 를 보내도 플로팅 UI가 떠요."
    }
}
