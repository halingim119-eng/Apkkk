package com.rbxbot.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.Executors

const val KAKAO = "com.kakao.talk"

class KakaoAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var inst: KakaoAccessibilityService? = null
    }

    @Volatile private var busyUi = false
    @Volatile private var scheduled = false
    @Volatile private var lastRoom = "\u0000"
    @Volatile private var lastSnap: List<String> = emptyList()
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var dumpCount = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        L.d(this, "접근성 서비스 연결됨")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (inst === this) inst = null
        L.d(this, "접근성 서비스 연결 해제")
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName?.toString() != KAKAO) return
        val t = e.eventType
        L.rl(this, "ev", 5000, "카톡 이벤트 수신 type=$t (카톡 쓰는 중에 이 줄이 안 뜨면 접근성이 이벤트를 못 받는 거예요)")
        if (!Prefs.b(this, "enabled") || !Prefs.b(this, "useAcc")) return

        if (t == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            onInput(e)
            return
        }
        if (busyUi || scheduled) return
        if (t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        scheduled = true
        h.postDelayed({
            scheduled = false
            exec.execute {
                try { scan() } catch (ex: Exception) { L.d(this, "스캔 오류: $ex") }
            }
        }, 300)
    }

    // ---------- 내가 보낸 메시지: 입력창이 한 번에 비워지면 '보냈다'고 봄 ----------

    private fun onInput(e: AccessibilityEvent) {
        if (busyUi) return
        val before = e.beforeText?.toString()?.trim() ?: return
        if (before.isEmpty()) return
        if (e.addedCount != 0 || e.removedCount < before.length) return
        L.d(this, "입력창 비워짐(내가 보냄 추정) before='${L.cut(before)}'")
        exec.execute {
            try {
                val root = rootInActiveWindow
                val room = if (root != null) snapshot(root).first else ""
                BotEngine.onMessage(applicationContext, room, before, "input")
            } catch (ex: Exception) {
                L.d(this, "입력 처리 오류: $ex")
            }
        }
    }

    // ---------- 화면 읽기 (남이 보낸 메시지 + 내 메시지) ----------

    private fun scan() {
        if (busyUi) return
        val root = rootInActiveWindow
        if (root == null) {
            L.rl(this, "noroot", 5000, "스캔: 활성 창 없음")
            return
        }
        if (root.packageName?.toString() != KAKAO) {
            L.rl(this, "notkakao", 5000, "스캔: 활성 창이 카톡이 아님 (${root.packageName})")
            return
        }
        if (findEditable(root) == null) {
            L.rl(this, "noedit", 5000, "스캔: 입력창을 못 찾음 → 채팅방 화면이 아니라고 판단 (로그 화면의 '화면 덤프'로 구조 확인)")
            return
        }
        val (title, texts) = snapshot(root)
        L.rl(this, "scan", 4000, "스캔 방='${L.cut(title)}' 텍스트 ${texts.size}개 끝=${texts.takeLast(3).map { L.cut(it, 20) }}")
        if (title != lastRoom) {
            lastRoom = title
            lastSnap = texts
            L.d(this, "방 변경/첫 스캔 → 기준 저장 '${L.cut(title)}'")
            return
        }
        val fresh = newTexts(lastSnap, texts)
        lastSnap = texts
        if (fresh.isNotEmpty()) {
            L.d(this, "새 텍스트 ${fresh.size}개: ${fresh.take(6).map { L.cut(it, 30) }}")
            for (m in fresh) BotEngine.onMessage(applicationContext, title, m, "acc")
        }
    }

    private fun snapshot(root: AccessibilityNodeInfo): Pair<String, List<String>> {
        val items = ArrayList<Triple<Int, Int, String>>()
        val r = Rect()
        walk(root, 0) { n ->
            val t = (n.text?.toString() ?: n.contentDescription?.toString())?.trim()
            if (!t.isNullOrEmpty() && !n.isEditable && n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                items.add(Triple(r.top, r.left, t))
            }
        }
        items.sortWith(compareBy<Triple<Int, Int, String>>({ it.first }, { it.second }))
        val limit = resources.displayMetrics.heightPixels * 0.18
        val title = items.firstOrNull { it.first < limit && !it.third.all { c -> c.isDigit() } }?.third ?: ""
        return Pair(title, items.map { it.third })
    }

    private fun newTexts(old: List<String>, cur: List<String>): List<String> {
        if (old.isEmpty() || cur.isEmpty()) return emptyList()
        var k = minOf(old.size, 4)
        while (k >= 1) {
            val tail = old.takeLast(k)
            var i = cur.size - k
            while (i >= 0) {
                if (cur.subList(i, i + k) == tail) return cur.subList(i + k, cur.size).toList()
                i--
            }
            k--
        }
        return emptyList()
    }

    // ---------- 화면 구조 덤프 (진단용) ----------

    fun dump() {
        val root = rootInActiveWindow
        if (root == null) {
            L.d(this, "덤프: 활성 창 없음")
            return
        }
        L.d(this, "===== 덤프 시작 pkg=${root.packageName} =====")
        dumpCount = 0
        dumpNode(root, 0)
        L.d(this, "===== 덤프 끝 (${dumpCount}개) =====")
    }

    private fun dumpNode(n: AccessibilityNodeInfo?, depth: Int) {
        if (n == null || depth > 45 || dumpCount >= 300) return
        dumpCount++
        val r = Rect()
        n.getBoundsInScreen(r)
        val flags = (if (n.isEditable) "E" else "") + (if (n.isClickable) "C" else "") + (if (n.isVisibleToUser) "V" else "")
        val cls = (n.className ?: "").toString().substringAfterLast('.')
        val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
        L.d(this, "${"·".repeat(depth)}$cls [$flags] t='${L.cut(n.text?.toString(), 40)}' d='${L.cut(n.contentDescription?.toString(), 30)}' id=$id y=${r.top}")
        for (i in 0 until n.childCount) dumpNode(n.getChild(i), depth + 1)
    }

    // ---------- 보내기 ----------

    fun canSendHere(room: String, trust: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != KAKAO || findEditable(root) == null) return false
        val title = snapshot(root).first
        return if (title.isEmpty()) trust else (title == room || title.contains(room) || room.contains(title))
    }

    fun inRoomSend(text: String): Boolean {
        busyUi = true
        try {
            val root = rootInActiveWindow ?: return false
            val input = findEditable(root) ?: return false
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                L.d(this, "입력창에 글자 넣기 실패")
                return false
            }
            Thread.sleep(500)
            val r2 = rootInActiveWindow ?: return false
            val send = findNode(r2) { !it.isEditable && label(it) == "전송" }
            if (send == null) {
                L.d(this, "전송 버튼을 못 찾음 (덤프로 확인 필요)")
                return false
            }
            val ok = clickUp(send)
            Thread.sleep(600)
            return ok
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    /** 카톡 공유 화면에서 방 검색 -> 선택 -> 확인 */
    fun autoPick(room: String, timeoutMs: Long = 25000): Boolean {
        busyUi = true
        try {
            var stage = 0
            var clicks = 0
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (SystemClock.elapsedRealtime() < end) {
                Thread.sleep(700)
                val root = rootInActiveWindow ?: continue
                if (root.packageName?.toString() != KAKAO) continue
                if (stage < 2) {
                    val target = findNode(root) { !it.isEditable && label(it) == room }
                    if (target != null) {
                        if (clickUp(target)) stage = 2
                    } else if (stage == 0) {
                        val ed = findEditable(root)
                        if (ed != null) {
                            val a = Bundle()
                            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, room)
                            ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
                            stage = 1
                        }
                    }
                } else {
                    val words = if (findEditable(root) == null) setOf("확인", "보내기", "전송") else setOf("확인", "보내기")
                    val ok = findNode(root) { !it.isEditable && label(it) in words }
                    if (ok != null) {
                        clickUp(ok)
                        clicks++
                        if (clicks >= 2) {
                            Thread.sleep(1200)
                            return true
                        }
                    } else if (clicks >= 1) {
                        Thread.sleep(1000)
                        return true
                    }
                }
            }
            L.d(this, "공유 화면 자동 선택 시간 초과 (stage=$stage)")
            return false
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    // ---------- 도구 ----------

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun findNode(root: AccessibilityNodeInfo, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var r: AccessibilityNodeInfo? = null
        walk(root, 0) { if (r == null && p(it)) r = it }
        return r
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        findNode(root) { it.isEditable || (it.className?.toString() ?: "").contains("EditText") }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            d++
        }
        return false
    }
}
