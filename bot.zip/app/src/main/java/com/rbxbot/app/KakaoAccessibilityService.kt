package com.rbxbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.util.concurrent.Executors

const val KAKAO = "com.kakao.talk"

class KakaoAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var inst: KakaoAccessibilityService? = null
    }

    @Volatile private var busyUi = false
    @Volatile private var scheduled = false
    @Volatile private var scanning = false
    @Volatile private var lastRoom = "\u0000"
    @Volatile private var lastSnap: List<String> = emptyList()
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var panel: OverlayPanel? = null

    /** 이벤트가 안 와도 1.2초마다 카톡 화면을 직접 확인 (확실히 감지하려고) */
    private val poll = object : Runnable {
        override fun run() {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                val me = this@KakaoAccessibilityService
                if (pm.isInteractive && !busyUi && !scanning && Prefs.b(me, "enabled") && Prefs.b(me, "useAcc")) {
                    exec.execute { runScan() }
                }
            } catch (e: Exception) {
            }
            h.postDelayed(this, 1200)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        L.d(this, "접근성 서비스 연결됨")
        h.post(poll)
        if (Prefs.raw(this, "panelOn", "0") == "1") showPanel()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (inst === this) inst = null
        h.removeCallbacks(poll)
        h.post { panel?.hide() }
        L.d(this, "접근성 서비스 연결 해제")
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    // ---------- 플로팅 UI ----------

    private fun panelObj(): OverlayPanel {
        var p = panel
        if (p == null) {
            p = OverlayPanel(this)
            panel = p
        }
        return p
    }

    fun showPanel() {
        h.post {
            try {
                panelObj().show()
                Prefs.put(this, "panelOn", "1")
            } catch (e: Exception) {
                L.d(this, "플로팅 UI 표시 오류: $e")
            }
        }
    }

    fun togglePanel() {
        h.post {
            try {
                val p = panelObj()
                if (p.isShown) {
                    p.hide()
                    Prefs.put(this, "panelOn", "0")
                } else {
                    p.show()
                    Prefs.put(this, "panelOn", "1")
                }
            } catch (e: Exception) {
                L.d(this, "플로팅 UI 오류: $e")
            }
        }
    }

    // ---------- 이벤트 ----------

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName?.toString() != KAKAO) return
        val t = e.eventType
        Status.lastKakaoEvent = System.currentTimeMillis()
        L.rl(this, "ev", 5000, "카톡 이벤트 수신 type=$t")
        if (!Prefs.b(this, "enabled")) return

        when (t) {
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> onNotiEvent(e)
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> if (Prefs.b(this, "useAcc")) onInput(e)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED, AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (Prefs.b(this, "useAcc") && !busyUi && !scheduled) {
                    scheduled = true
                    h.postDelayed({
                        scheduled = false
                        exec.execute { runScan() }
                    }, 300)
                }
            }
        }
    }

    /** 접근성으로 받은 알림 (알림 리스너가 안 돼도 이쪽으로 들어옴) */
    private fun onNotiEvent(e: AccessibilityEvent) {
        if (!Prefs.b(this, "useNoti")) return
        val n = e.parcelableData as? Notification ?: return
        val fb = e.text.joinToString(" ")
        exec.execute {
            try {
                NotiHandler.handle(applicationContext, n, "접근성", fb)
            } catch (ex: Exception) {
                L.d(this, "알림 이벤트 처리 오류: $ex")
            }
        }
    }

    /** 내가 보낸 메시지: 입력창이 한 번에 비워지면 '보냈다'고 봄 */
    private fun onInput(e: AccessibilityEvent) {
        if (busyUi) return
        val before = e.beforeText?.toString()?.trim() ?: return
        if (before.isEmpty()) return
        if (e.addedCount != 0 || e.removedCount < before.length) return
        L.d(this, "입력창 비워짐(내가 보냄 추정) before='${L.cut(before)}'")
        exec.execute {
            try {
                val root = kakaoRoot()
                val room = if (root != null) roomTitle(root) else ""
                BotEngine.onMessage(applicationContext, room, before, "input")
            } catch (ex: Exception) {
                L.d(this, "입력 처리 오류: $ex")
            }
        }
    }

    // ---------- 화면 읽기 ----------

    private fun runScan() {
        if (scanning || busyUi) return
        scanning = true
        try {
            scan()
        } catch (ex: Exception) {
            L.d(this, "스캔 오류: $ex")
        } finally {
            scanning = false
        }
    }

    private fun scan() {
        val root = kakaoRoot()
        if (root == null) {
            L.rl(this, "nokakao", 60000, "스캔: 지금 화면에 카톡 창이 없음")
            return
        }
        if (findEditable(root) == null) {
            L.rl(this, "noedit", 8000, "스캔: 입력창을 못 찾음 → 채팅방이 아니라고 판단 (플로팅 UI의 '덤프'로 구조 확인)")
            return
        }
        val (title, texts) = snapshot(root)
        L.rl(this, "scan", 4000, "스캔 방='${L.cut(title)}' 글자 ${texts.size}개 끝=${texts.takeLast(3).map { L.cut(it, 20) }}")
        if (title != lastRoom) {
            lastRoom = title
            lastSnap = texts
            L.d(this, "방 변경/첫 스캔 → 기준 저장 '${L.cut(title)}'")
            return
        }
        val fresh = newTexts(lastSnap, texts)
        lastSnap = texts
        if (fresh.isNotEmpty()) {
            L.d(this, "새 글자 ${fresh.size}개: ${fresh.take(6).map { L.cut(it, 30) }}")
            for (m in fresh) BotEngine.onMessage(applicationContext, title, m, "acc")
        }
    }

    private fun textOf(n: AccessibilityNodeInfo): String? {
        val t = n.text?.toString()?.trim()
        if (!t.isNullOrEmpty()) return t
        return n.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun byId(root: AccessibilityNodeInfo, id: String): List<AccessibilityNodeInfo> =
        try {
            root.findAccessibilityNodeInfosByViewId("$KAKAO:id/$id") ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

    private fun idOf(n: AccessibilityNodeInfo): String = n.viewIdResourceName ?: ""

    private val ignoreTitles = setOf("뒤로", "검색", "보이스톡", "메뉴 더보기", "메뉴")

    /** 방 이름: 카톡 툴바 제목(toolbar_default_title_text)에서 읽음 */
    private fun roomTitle(root: AccessibilityNodeInfo): String {
        val n = byId(root, "toolbar_default_title_text").firstOrNull()
        val t = if (n != null) textOf(n) else null
        if (!t.isNullOrEmpty()) return t
        return snapshotGeneric(root).first
    }

    /** 카톡 채팅방: 메시지 글자(id=message)만 위에서 아래 순서로 읽음 */
    private fun snapshot(root: AccessibilityNodeInfo): Pair<String, List<String>> {
        val msgNodes = byId(root, "message")
        if (msgNodes.isEmpty()) return snapshotGeneric(root)
        val r = Rect()
        val items = ArrayList<Pair<Int, String>>()
        for (n in msgNodes) {
            val t = textOf(n)
            if (t == null || !n.isVisibleToUser) continue
            n.getBoundsInScreen(r)
            items.add(Pair(r.top, t))
        }
        items.sortBy { it.first }
        return Pair(roomTitle(root), items.map { it.second })
    }

    /** 채팅 메시지 목록(가장 큰 스크롤 영역)만 읽어서 입력창/툴바 글자가 섞이지 않게 함 */
    private fun chatList(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0L
        val r = Rect()
        walk(root, 0) { n ->
            if (n.isScrollable && !n.isEditable) {
                n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height().toLong()
                if (a > bestArea) {
                    bestArea = a
                    best = n
                }
            }
        }
        return best
    }

    private fun snapshotGeneric(root: AccessibilityNodeInfo): Pair<String, List<String>> {
        val list = chatList(root)
        val lr = Rect()
        list?.getBoundsInScreen(lr)
        val items = ArrayList<Triple<Int, Int, String>>()
        val head = ArrayList<Triple<Int, Int, String>>()
        val r = Rect()
        walk(list ?: root, 0) { n ->
            val t = textOf(n)
            if (t != null && !n.isEditable && n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                items.add(Triple(r.top, r.left, t))
            }
        }
        if (list != null) {
            walk(root, 0) { n ->
                val t = textOf(n)
                if (t != null && !n.isEditable && n.isVisibleToUser) {
                    n.getBoundsInScreen(r)
                    if (r.bottom <= lr.top + 8) head.add(Triple(r.top, r.left, t))
                }
            }
        }
        val cmp = compareBy<Triple<Int, Int, String>>({ it.first }, { it.second })
        items.sortWith(cmp)
        head.sortWith(cmp)
        val title = if (list != null) {
            head.firstOrNull { !it.third.all { c -> c.isDigit() } && it.third !in ignoreTitles }?.third ?: ""
        } else {
            val limit = resources.displayMetrics.heightPixels * 0.18
            items.firstOrNull { it.first < limit && !it.third.all { c -> c.isDigit() } }?.third ?: ""
        }
        return Pair(title, items.map { it.third })
    }

    private fun newTexts(old: List<String>, cur: List<String>): List<String> {
        if (old.isEmpty() || cur.isEmpty()) return emptyList()
        var k = minOf(old.size, 5)
        while (k >= 1) {
            val tail = old.takeLast(k)
            var i = cur.size - k
            while (i >= 0) {
                if (cur.subList(i, i + k) == tail) return cur.subList(i + k, cur.size).toList()
                i--
            }
            k--
        }
        return emptyList()
    }

    // ---------- 창 찾기 (플로팅 UI가 떠 있어도 카톡 창을 찾음) ----------

    private fun appRoots(): List<Pair<Int, AccessibilityNodeInfo>> {
        val out = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        try {
            val ws = windows ?: emptyList<AccessibilityWindowInfo>()
            for (w in ws) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                if (r.packageName?.toString() == packageName) continue
                out.add(Pair(w.layer, r))
            }
        } catch (e: Exception) {
        }
        out.sortByDescending { it.first }
        return out
    }

    fun kakaoRoot(): AccessibilityNodeInfo? {
        val a = rootInActiveWindow
        if (a != null && a.packageName?.toString() == KAKAO) return a
        for (p in appRoots()) if (p.second.packageName?.toString() == KAKAO) return p.second
        return null
    }

    // ---------- 현재 화면 덤프 (어떤 앱이든) ----------

    fun dumpScreen(): String {
        val sb = StringBuilder()
        var ws: List<AccessibilityWindowInfo> = emptyList()
        try {
            ws = windows ?: emptyList()
        } catch (e: Exception) {
            sb.append("windows 조회 실패: $e\n")
        }
        sb.append("[창 ${ws.size}개]\n")
        for (w in ws) {
            sb.append("  type=${w.type} layer=${w.layer} active=${w.isActive} pkg=${w.root?.packageName}\n")
        }
        val target = appRoots().firstOrNull()?.second ?: rootInActiveWindow
        if (target == null) {
            sb.append("(덤프할 앱 창을 못 찾았어요)\n")
            return sb.toString()
        }
        sb.append("[덤프 대상] pkg=${target.packageName}\n")
        val cnt = IntArray(1)
        dumpNode(target, 0, sb, cnt)
        sb.append("[끝] 노드 ${cnt[0]}개\n")
        return sb.toString()
    }

    private fun dumpNode(n: AccessibilityNodeInfo?, depth: Int, sb: StringBuilder, cnt: IntArray) {
        if (n == null || depth > 45 || cnt[0] >= 400) return
        cnt[0]++
        val r = Rect()
        n.getBoundsInScreen(r)
        val flags = (if (n.isEditable) "E" else "") + (if (n.isClickable) "C" else "") +
            (if (n.isScrollable) "S" else "") + (if (n.isVisibleToUser) "V" else "")
        val cls = (n.className ?: "").toString().substringAfterLast('.')
        val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
        sb.append("·".repeat(depth)).append(cls).append(" [").append(flags).append("] t='")
            .append(L.cut(n.text?.toString(), 40)).append("' d='")
            .append(L.cut(n.contentDescription?.toString(), 30)).append("' id=").append(id)
            .append(" b=").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append('\n')
        for (i in 0 until n.childCount) dumpNode(n.getChild(i), depth + 1, sb, cnt)
    }

    // ---------- 보내기 ----------

    fun canSendHere(room: String, trust: Boolean): Boolean {
        val root = kakaoRoot() ?: return false
        if (findEditable(root) == null) return false
        val title = roomTitle(root)
        return if (title.isEmpty()) trust else (title == room || title.contains(room) || room.contains(title))
    }

    fun inRoomSend(text: String): Boolean {
        busyUi = true
        try {
            val root = kakaoRoot()
            if (root == null) {
                L.d(this, "전송: 카톡 창을 못 찾음")
                return false
            }
            val input = findEditable(root)
            if (input == null) {
                L.d(this, "전송: 입력창을 못 찾음")
                return false
            }
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                L.d(this, "전송: 입력창에 글자 넣기 실패")
                return false
            }
            Thread.sleep(600)
            val ok = pressSend(text)
            L.d(this, "전송 버튼 결과=$ok")
            if (!ok) clearInput()
            Thread.sleep(500)
            return ok
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    private fun clearInput() {
        try {
            val ed = kakaoRoot()?.let { findEditable(it) } ?: return
            val a = Bundle()
            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
        } catch (e: Exception) {
        }
    }

    /** 입력창에서 방금 넣은 글자가 사라졌으면 전송된 것 */
    private fun sentCheck(typed: String): Boolean {
        val root = kakaoRoot() ?: return false
        val ed = findEditable(root) ?: return false
        val cur = ed.text?.toString() ?: ""
        return !cur.contains(typed.take(8))
    }

    /** 전송 버튼(id=send_layout): 클릭 -> 안 되면 좌표 탭 */
    private fun pressSend(typed: String): Boolean {
        for (attempt in 1..3) {
            val root = kakaoRoot() ?: return false
            val send = byId(root, "send_layout").firstOrNull()
                ?: findNode(root) { !it.isEditable && label(it) == "전송" }
            if (send == null) {
                L.d(this, "전송 버튼을 못 찾음 (시도 $attempt)")
                Thread.sleep(400)
                continue
            }
            val r = Rect()
            send.getBoundsInScreen(r)
            L.d(this, "전송 버튼 후보 id=${idOf(send)} clickable=${send.isClickable} bounds=${r.left},${r.top},${r.right},${r.bottom} (시도 $attempt)")
            val c = clickDown(send, 0)
            Thread.sleep(500)
            if (sentCheck(typed)) {
                L.d(this, "→ 클릭($c)으로 전송됨")
                return true
            }
            if (!r.isEmpty) {
                val t = tap(r.exactCenterX(), r.exactCenterY())
                Thread.sleep(700)
                if (sentCheck(typed)) {
                    L.d(this, "→ 좌표 탭($t)으로 전송됨")
                    return true
                }
            }
        }
        return false
    }

    private fun clickDown(n: AccessibilityNodeInfo, depth: Int): Boolean {
        if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        if (depth > 4) return false
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (clickDown(c, depth + 1)) return true
        }
        return false
    }

    private fun tap(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            L.d(this, "좌표 탭 실패: $e")
            false
        }
    }

    /** 카톡 공유 화면에서 방 검색 -> 선택 -> 확인 */
    fun autoPick(room: String, timeoutMs: Long = 25000): Boolean {
        busyUi = true
        try {
            var stage = 0
            var clicks = 0
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (SystemClock.elapsedRealtime() < end) {
                Thread.sleep(700)
                val root = kakaoRoot()
                if (root == null) {
                    if (stage == 0 && clickChooser()) L.d(this, "공유 목록(시스템)에서 카카오톡 항목 클릭")
                    continue
                }
                if (stage < 2) {
                    val target = findNode(root) { !it.isEditable && label(it) == room }
                    if (target != null) {
                        if (clickUp(target)) stage = 2
                    } else if (stage == 0) {
                        val ed = findEditable(root)
                        if (ed != null) {
                            val a = Bundle()
                            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, room)
                            ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
                            stage = 1
                        }
                    }
                } else {
                    val words = if (findEditable(root) == null) setOf("확인", "보내기", "전송") else setOf("확인", "보내기")
                    val ok = findNode(root) { !it.isEditable && label(it) in words }
                    if (ok != null) {
                        clickUp(ok)
                        clicks++
                        if (clicks >= 2) {
                            Thread.sleep(1200)
                            return true
                        }
                    } else if (clicks >= 1) {
                        Thread.sleep(1000)
                        return true
                    }
                }
            }
            L.d(this, "공유 화면 자동 선택 시간 초과 (stage=$stage)")
            return false
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    /** 시스템 공유 목록(카카오톡 외 창)에 뜬 카카오톡 항목을 눌러줌 */
    private fun clickChooser(): Boolean {
        for (p in appRoots()) {
            val r = p.second
            if (r.packageName?.toString() == KAKAO) continue
            val n = findNode(r) { !it.isEditable && label(it).contains("카카오톡") }
                ?: findNode(r) { !it.isEditable && label(it).startsWith("Android") }
            if (n != null && clickUp(n)) return true
        }
        return false
    }

    /** 방 안에서 + → 파일 → 파일 선택 → 전송 (공유창을 안 쓰는 방식) */
    fun attachFile(fileName: String, timeoutMs: Long = 40000): Boolean {
        busyUi = true
        try {
            var stage = 0
            val end = SystemClock.elapsedRealtime() + timeoutMs
            val plusWords = setOf("더보기", "메뉴", "첨부", "추가", "+", "파일 첨부", "메뉴 더보기")
            while (SystemClock.elapsedRealtime() < end) {
                Thread.sleep(800)
                val root = kakaoRoot() ?: continue
                when (stage) {
                    0 -> {
                        val plus = findNode(root) { n ->
                            val id = idOf(n).lowercase()
                            !n.isEditable && (id.contains("plus") || id.contains("attach") || id.contains("more_btn") ||
                                label(n) in plusWords)
                        }
                        if (plus != null && clickUp(plus)) { stage = 1; L.d(this, "+ 버튼 클릭") }
                    }
                    1 -> {
                        val f = findNode(root) { !it.isEditable && label(it) == "파일" }
                        if (f != null && clickUp(f)) { stage = 2; L.d(this, "'파일' 클릭") }
                    }
                    2 -> {
                        val f = findNode(root) { !it.isEditable && label(it).contains(fileName) }
                        if (f != null && clickUp(f)) { stage = 3; L.d(this, "파일 선택 '$fileName'") }
                    }
                    3 -> {
                        val ok = findNode(root) { !it.isEditable && label(it) in setOf("전송", "보내기", "확인") }
                        if (ok != null && clickUp(ok)) {
                            Thread.sleep(1500)
                            return true
                        }
                    }
                }
            }
            L.d(this, "방 안 첨부 시간 초과 (stage=$stage)\n" + dumpScreen().take(3000))
            return false
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    // ---------- 도구 ----------

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun findNode(root: AccessibilityNodeInfo, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var r: AccessibilityNodeInfo? = null
        walk(root, 0) { if (r == null && p(it)) r = it }
        return r
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        byId(root, "message_edit_text").firstOrNull()
            ?: findNode(root) { it.isEditable || (it.className?.toString() ?: "").contains("EditText") }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            d++
        }
        return false
    }
}
