package com.rbxbot.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.Executors

const val KAKAO = "com.kakao.talk"

class KakaoAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var inst: KakaoAccessibilityService? = null
    }

    @Volatile private var busyUi = false
    @Volatile private var scheduled = false
    @Volatile private var lastRoom = "\u0000"
    @Volatile private var lastSnap: List<String> = emptyList()
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (inst === this) inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName?.toString() != KAKAO) return
        if (busyUi || scheduled) return
        val t = e.eventType
        if (t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Prefs.b(this, "enabled") || !Prefs.b(this, "useAcc")) return
        scheduled = true
        h.postDelayed({
            scheduled = false
            exec.execute {
                try { scan() } catch (ex: Exception) { }
            }
        }, 300)
    }

    // ---------- 화면 읽기 ----------

    private fun scan() {
        if (busyUi) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != KAKAO) return
        if (findEditable(root) == null) return // 채팅방 화면만 (입력창이 있는 화면)
        val (title, texts) = snapshot(root)
        if (title != lastRoom) {
            lastRoom = title
            lastSnap = texts
            return
        }
        val fresh = newTexts(lastSnap, texts)
        lastSnap = texts
        for (m in fresh) BotEngine.onMessage(applicationContext, title, m, "acc")
    }

    private fun snapshot(root: AccessibilityNodeInfo): Pair<String, List<String>> {
        val items = ArrayList<Triple<Int, Int, String>>()
        val r = Rect()
        walk(root, 0) { n ->
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && !n.isEditable && n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                items.add(Triple(r.top, r.left, t))
            }
        }
        items.sortWith(compareBy<Triple<Int, Int, String>>({ it.first }, { it.second }))
        val limit = resources.displayMetrics.heightPixels * 0.18
        val title = items.firstOrNull { it.first < limit && !it.third.all { c -> c.isDigit() } }?.third ?: ""
        return Pair(title, items.map { it.third })
    }

    /** 이전 화면의 끝부분을 새 화면에서 찾아서, 그 뒤에 붙은 것만 '새 메시지'로 봄 */
    private fun newTexts(old: List<String>, cur: List<String>): List<String> {
        if (old.isEmpty() || cur.isEmpty()) return emptyList()
        var k = minOf(old.size, 4)
        while (k >= 1) {
            val tail = old.takeLast(k)
            var i = cur.size - k
            while (i >= 0) {
                if (cur.subList(i, i + k) == tail) return cur.subList(i + k, cur.size).toList()
                i--
            }
            k--
        }
        return emptyList()
    }

    // ---------- 보내기 ----------

    fun canSendHere(room: String, trust: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != KAKAO || findEditable(root) == null) return false
        val title = snapshot(root).first
        return if (title.isEmpty()) trust else (title == room || title.contains(room) || room.contains(title))
    }

    fun inRoomSend(text: String): Boolean {
        busyUi = true
        try {
            val root = rootInActiveWindow ?: return false
            val input = findEditable(root) ?: return false
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
            Thread.sleep(500)
            val r2 = rootInActiveWindow ?: return false
            val send = findNode(r2) { !it.isEditable && label(it) == "전송" } ?: return false
            val ok = clickUp(send)
            Thread.sleep(600)
            return ok
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    /** 카톡 공유 화면에서 방 검색 -> 선택 -> 확인까지 눌러줌 */
    fun autoPick(room: String, timeoutMs: Long = 25000): Boolean {
        busyUi = true
        try {
            var stage = 0
            var clicks = 0
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (SystemClock.elapsedRealtime() < end) {
                Thread.sleep(700)
                val root = rootInActiveWindow ?: continue
                if (root.packageName?.toString() != KAKAO) continue
                if (stage < 2) {
                    val target = findNode(root) { !it.isEditable && label(it) == room }
                    if (target != null) {
                        if (clickUp(target)) stage = 2
                    } else if (stage == 0) {
                        val ed = findEditable(root)
                        if (ed != null) {
                            val a = Bundle()
                            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, room)
                            ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
                            stage = 1
                        }
                    }
                } else {
                    val words = if (findEditable(root) == null) setOf("확인", "보내기", "전송") else setOf("확인", "보내기")
                    val ok = findNode(root) { !it.isEditable && label(it) in words }
                    if (ok != null) {
                        clickUp(ok)
                        clicks++
                        if (clicks >= 2) {
                            Thread.sleep(1200)
                            return true
                        }
                    } else if (clicks >= 1) {
                        Thread.sleep(1000)
                        return true
                    }
                }
            }
            return false
        } finally {
            busyUi = false
            lastRoom = "\u0000"
            lastSnap = emptyList()
        }
    }

    // ---------- 도구 ----------

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun findNode(root: AccessibilityNodeInfo, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var r: AccessibilityNodeInfo? = null
        walk(root, 0) { if (r == null && p(it)) r = it }
        return r
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        findNode(root) { it.isEditable && it.isVisibleToUser }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            d++
        }
        return false
    }
}
