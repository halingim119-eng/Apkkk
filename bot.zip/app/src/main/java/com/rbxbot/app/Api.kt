package com.rbxbot.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Video(val id: String, val title: String, val channel: String)
data class Comment(val author: String, val body: String)
data class Detail(val description: String, val comments: List<Comment>)

object Api {
    const val BASE = "https://tubeshelf-search-20261122.carvedcocoa512.chatgpt.site"

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun fetch(url: String, tries: Int = 2, ct: Int = 20000, rt: Int = 40000): ByteArray? {
        for (attempt in 0 until tries) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = ct
                c.readTimeout = rt
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                if (c.responseCode in 200..299) {
                    return c.inputStream.use { it.readBytes() }
                }
                c.disconnect()
            } catch (e: Exception) {
                // 재시도
            }
            if (attempt < tries - 1) {
                try { Thread.sleep(800) } catch (e: InterruptedException) { return null }
            }
        }
        return null
    }

    private fun parse(b: ByteArray): JSONObject? =
        try { JSONObject(String(b, Charsets.UTF_8)) } catch (e: Exception) { null }

    fun search(q: String): List<Video> {
        val j = fetch("$BASE/api/search?q=${enc(q)}")?.let { parse(it) } ?: return emptyList()
        val arr = j.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<Video>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isEmpty()) continue
            out.add(Video(id, o.optString("title"), o.optString("channel")))
        }
        return out
    }

    fun video(id: String): Detail? {
        val j = fetch("$BASE/api/video?id=${enc(id)}")?.let { parse(it) } ?: return null
        if (j.has("error")) return null
        val cs = ArrayList<Comment>()
        val arr = j.optJSONArray("comments")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                cs.add(Comment(o.optString("author"), o.optString("body")))
            }
        }
        return Detail(j.optString("description"), cs)
    }

    /** Pastefy에 게시물 생성 → raw 링크 (실패하면 null) */
    fun paste(key: String, title: String, content: String): String? {
        return try {
            val c = URL("https://pastefy.app/api/v2/paste").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 40000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            val body = JSONObject().put("title", title).put("content", content).put("visibility", "UNLISTED")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) return null
            val j = JSONObject(c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) })
            val id = (j.optJSONObject("paste") ?: j).optString("id")
            if (id.isEmpty()) null else "https://pastefy.app/$id/raw"
        } catch (e: Exception) {
            null
        }
    }
}
