package com.rbxbot.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Video(val id: String, val title: String, val channel: String)
data class Comment(val author: String, val body: String)
data class Detail(val description: String, val comments: List<Comment>)

object Api {
    const val BASE = "https://tubeshelf-search-20261122.carvedcocoa512.chatgpt.site"

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun fetch(url: String, tries: Int = 2, ct: Int = 20000, rt: Int = 40000): ByteArray? {
        for (attempt in 0 until tries) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = ct
                c.readTimeout = rt
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                if (c.responseCode in 200..299) {
                    return c.inputStream.use { it.readBytes() }
                }
                c.disconnect()
            } catch (e: Exception) {
                // 재시도
            }
            if (attempt < tries - 1) {
                try { Thread.sleep(800) } catch (e: InterruptedException) { return null }
            }
        }
        return null
    }

    private fun parse(b: ByteArray): JSONObject? =
        try { JSONObject(String(b, Charsets.UTF_8)) } catch (e: Exception) { null }

    fun search(q: String): List<Video> {
        val j = fetch("$BASE/api/search?q=${enc(q)}")?.let { parse(it) } ?: return emptyList()
        val arr = j.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<Video>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isEmpty()) continue
            out.add(Video(id, o.optString("title"), o.optString("channel")))
        }
        return out
    }

    fun video(id: String): Detail? {
        val j = fetch("$BASE/api/video?id=${enc(id)}")?.let { parse(it) } ?: return null
        if (j.has("error")) return null
        val cs = ArrayList<Comment>()
        val arr = j.optJSONArray("comments")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                cs.add(Comment(o.optString("author"), o.optString("body")))
            }
        }
        return Detail(j.optString("description"), cs)
    }

    /** Pastefy에 게시물 생성 → raw 링크 (실패하면 null) */
    fun paste(key: String, title: String, content: String): String? {
        return try {
            val c = URL("https://pastefy.app/api/v2/paste").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 40000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            val body = JSONObject().put("title", title).put("content", content).put("visibility", "UNLISTED")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) return null
            val j = JSONObject(c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) })
            val id = (j.optJSONObject("paste") ?: j).optString("id")
            if (id.isEmpty()) null else "https://pastefy.app/$id/raw"
        } catch (e: Exception) {
            null
        }
    }

    private fun call(method: String, url: String, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 40000
        c.setRequestProperty("Accept", "application/json, text/plain;q=0.9, */*;q=0.8")
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; SM-S918N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36")
        c.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7")
        if (url.contains("usebyp") && !url.contains("/api/submit") && !url.contains("/api/result/")) {
            val o = url.substringBefore("/api/")
            c.setRequestProperty("Origin", o)
            c.setRequestProperty("Referer", "$o/")
        }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val text = st?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
        return Pair(code, text)
    }

    private fun cleanErr(t: String): String {
        if (!t.trimStart().startsWith("<")) return t.take(150)
        val code = Regex("Error code (\\d+)").find(t)?.groupValues?.get(1)
        val title = Regex("<title>([^<]*)</title>", RegexOption.IGNORE_CASE).find(t)?.groupValues?.get(1)?.trim()
        val cf = if (t.contains("cloudflare", true)) "Cloudflare가 막았어요" else "HTML 응답"
        return "$cf${if (code != null) " (코드 $code)" else ""}${if (!title.isNullOrEmpty()) " - $title" else ""}"
    }

    private const val V1_SUBMIT = "/api/v1/bypass/submit"
    private const val V1_RESULT = "/api/v1/bypass/result/"

    private fun runBypass(
        base: String, submitPath: String, resultPath: String, link: String,
        tx: (String, String, String?) -> Pair<Int, String>
    ): Pair<String?, String?> {
        var cur = try {
            tx("POST", "$base$submitPath", JSONObject().put("url", link).toString())
        } catch (e: Exception) {
            return Pair(null, "연결 실패: $e")
        }
        val end = System.currentTimeMillis() + 5 * 60 * 1000L
        while (true) {
            val code = cur.first
            val text = cur.second
            val j = try { JSONObject(text) } catch (e: Exception) { null }
            if (code !in 200..299) {
                val m = j?.optString("message").orEmpty().ifEmpty { cleanErr(text) }
                return Pair(null, "$code $m".trim())
            }
            if (j == null) {
                val u = Regex("https?://[^\\s\"<>]+").find(text)?.value
                return if (u != null) Pair(u, null) else Pair(null, "알 수 없는 응답: ${text.take(150)}")
            }
            val url = j.optJSONObject("result")?.optString("url").orEmpty()
            if (url.isNotEmpty()) return Pair(url, null)
            val status = j.optString("status").uppercase()
            val pending = code == 202 || status in setOf("PENDING", "QUEUED", "PROCESSING", "RUNNING")
            if (!pending) return Pair(null, j.optString("message").ifEmpty { "실패했어요 ($status)" })
            val id = j.optString("id")
            if (id.isEmpty()) return Pair(null, "요청 ID를 받지 못했어요")
            if (System.currentTimeMillis() > end) return Pair(null, "너무 오래 걸려서 중단했어요")
            try { Thread.sleep(2500) } catch (e: InterruptedException) { return Pair(null, "중단됨") }
            cur = try {
                tx("GET", "$base$resultPath$id", null)
            } catch (e: Exception) {
                return Pair(null, "결과 확인 실패: $e")
            }
        }
    }

    /** UseBypass 1회: 성공 Pair(결과링크, null) / 실패 Pair(null, 에러문구)
     *  Cloudflare(403)는 앱 안 WebView(진짜 브라우저 엔진)로 통과한 뒤 그 안에서 요청함 */
    fun bypass(ctx: Context, link: String): Pair<String?, String?> {
        val px = Prefs.s(ctx, "bypassProxy").trim().trimEnd('/')
        if (px.isNotEmpty()) return runBypass(px, "/api/submit", "/api/result/", link) { m, u, b -> call(m, u, b) }
        var last: Pair<String?, String?> = Pair(null, "연결 실패")
        for (base in listOf("https://usebypass.com", "https://usebypas.com")) {
            if (!BypassWeb.ensure(ctx, base)) {
                last = Pair(null, "Cloudflare 확인을 통과하지 못했어요 ($base)")
                continue
            }
            val r = runBypass(base, V1_SUBMIT, V1_RESULT, link) { m, u, b -> BypassWeb.fetch(m, u, b) }
            if (r.first != null) return r
            last = r
            val e = r.second ?: ""
            if (!(e.startsWith("403") || e.startsWith("연결") || e.startsWith("0 "))) return r
        }
        return last
    }

    fun isTarget(u: String): Boolean {
        val l = u.lowercase()
        return l.contains("pastebin.com") || l.contains("pastefy.app")
    }

    /** pastebin.com / pastefy.app 이 나올 때까지 바이패스를 반복 */
    fun bypassChain(ctx: Context, link: String, maxHops: Int = 6): Pair<String?, String?> {
        var cur = link
        for (i in 0 until maxHops) {
            if (isTarget(cur)) return Pair(cur, null)
            val (o, e) = bypass(ctx, cur)
            if (o == null) return Pair(null, e)
            if (o == cur) return Pair(null, "결과가 같은 링크예요")
            cur = o
        }
        return if (isTarget(cur)) Pair(cur, null) else Pair(null, "pastebin/pastefy까지 못 갔어요 (마지막: $cur)")
    }
}
