package com.rbxbot.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors

data class Hit(val video: Video, val links: List<String>)

object Scraper {
    /** 설정과 상관없이 항상 차단하는 링크 */
    private val BLOCKED = listOf("www.roblox.com", "whatsapp.com")

    /** 이 글자가 들어간 링크만 가져옴 */
    private val ALLOW = listOf("rekonise.com", "link-center", "linkvertise.com", "pastebin.com", "script", "pastefy")

    private val urlRe = Regex("""https?://[^\s<>"'`]+""")

    /** 기존 방식(검색어 + 확장 검색어)으로 영상을 최소 100개(설정값이 더 크면 그만큼) 모음 */
    fun searchAll(ctx: Context, query: String): List<Video> {
        val max = Prefs.i(ctx, "maxVideos").coerceIn(100, 500)
        val qs = ArrayList<String>()
        qs.add(query)
        for (s in Prefs.list(ctx, "expand")) {
            if (!query.contains(s, ignoreCase = true)) qs.add("$query $s")
        }
        val seen = LinkedHashMap<String, Video>()
        for (q in qs) {
            for (v in Api.search(q)) {
                if (seen.size >= max) break
                if (!seen.containsKey(v.id)) seen[v.id] = v
            }
            if (seen.size >= max) break
        }
        return seen.values.toList()
    }

    /** 진단용: [0] 정보 받은 영상 / [1] script 조건 통과 / [2] 댓글 확인한 영상 */
    @Volatile var stats = java.util.concurrent.atomic.AtomicIntegerArray(3)

    fun collect(ctx: Context, videos: List<Video>, st: java.util.concurrent.atomic.AtomicIntegerArray = stats): List<Hit> {
        val kws = Prefs.list(ctx, "keyword")
        val ex = Prefs.list(ctx, "exclude").map { it.lowercase() }
        val ownerOnly = Prefs.b(ctx, "ownerOnly")
        val info = Api.info(ctx, videos.map { it.id })
        val pool = Executors.newFixedThreadPool(Prefs.i(ctx, "threads").coerceIn(1, 16))
        try {
            val futures = videos.map { v -> pool.submit(Callable<Hit?> { analyze(ctx, v, info[v.id], kws, ex, ownerOnly, st) }) }
            val out = ArrayList<Hit>()
            for (f in futures) {
                try {
                    val h = f.get()
                    if (h != null) out.add(h)
                } catch (e: Exception) {
                    // 이 영상은 건너뜀
                }
            }
            return out
        } finally {
            pool.shutdown()
        }
    }

    private fun analyze(ctx: Context, v0: Video, vi: Api.VInfo?, kws: List<String>, ex: List<String>, ownerOnly: Boolean, st: java.util.concurrent.atomic.AtomicIntegerArray): Hit? {
        if (vi != null) st.incrementAndGet(0)
        val desc = vi?.description ?: ""
        val v = if (vi != null) v0.copy(channelId = vi.channelId, date = vi.date) else v0
        // 영상(제목/설명)에 감지 단어(script)가 있어야 함 (대소문자 무시)
        if (kws.isNotEmpty() && kws.none { v.title.contains(it, true) || desc.contains(it, true) }) return null
        st.incrementAndGet(1)
        val links = LinkedHashSet<String>()
        links.addAll(extract(desc, ex))
        // 설명란에 "comments"(대소문자 무시)가 있을 때만 댓글(50개)을 봄
        if (desc.contains("comments", ignoreCase = true)) {
            st.incrementAndGet(2)
            for (c in Api.comments(ctx, v.id)) {
                if (!ownerOnly || isOwner(c, v)) links.addAll(extract(c.body, ex))
            }
        }
        return if (links.isEmpty()) null else Hit(v, links.toList())
    }

    /** 링크 -> 그 링크를 얻은 영상 날짜 (여러 영상이면 가장 최근 날짜) */
    fun linkDates(hits: List<Hit>): Map<String, String> {
        val m = HashMap<String, String>()
        for (h in hits) for (l in h.links) {
            val cur = m[l]
            if (cur == null || h.video.date > cur) m[l] = h.video.date
        }
        return m
    }

    private fun extract(t: String, ex: List<String>): List<String> =
        urlRe.findAll(t)
            .map { it.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>') }
            .filter { u ->
                val l = u.lowercase()
                ALLOW.any { l.contains(it) } && BLOCKED.none { l.contains(it) } && ex.none { l.contains(it) }
            }
            .toList()

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun isOwner(cm: Comment, v: Video): Boolean {
        if (cm.authorId.isNotEmpty() && v.channelId.isNotEmpty()) return cm.authorId == v.channelId
        val a = norm(cm.author)
        val c = norm(v.channel)
        if (a.isEmpty() || c.isEmpty()) return false
        if (a == c) return true
        return a.length >= 3 && c.length >= 3 && (a.contains(c) || c.contains(a))
    }

    fun uniqueLinks(hits: List<Hit>): List<String> {
        val all = LinkedHashSet<String>()
        hits.forEach { all.addAll(it.links) }
        return all.toList()
    }

    fun reportText(query: String, total: Int, hits: List<Hit>): String {
        val all = uniqueLinks(hits)
        val idx = all.withIndex().associate { it.value to it.index + 1 }
        val L = ArrayList<String>()
        L.add("━━━━━━━━━━━━━━━━━━━━")
        L.add("  $query  스크립트 & 링크")
        L.add("━━━━━━━━━━━━━━━━━━━━")
        L.add("검사한 영상 ${total}개  ·  링크 나온 영상 ${hits.size}개  ·  링크 ${all.size}개")
        L.add("")
        L.add("■ 전체 링크")
        all.forEachIndexed { i, u -> L.add("[${i + 1}] $u") }
        L.add("")
        L.add("■ 영상별")
        for (h in hits) {
            L.add("")
            L.add("▶ ${h.video.title}  (${h.video.channel})" + (if (h.video.date.isNotEmpty()) "  ·  ${h.video.date}" else ""))
            L.add("   https://youtu.be/${h.video.id}")
            h.links.forEach { L.add("   └ [${idx[it]}] $it") }
        }
        L.add("")
        L.add("━━━━━━━━━━━━━━━━━━━━")
        return L.joinToString("\n") { if (it.isEmpty()) "|" else "| $it" }
    }

    fun report(ctx: Context, query: String, total: Int, hits: List<Hit>): File {
        val text = reportText(query, total, hits)
        val dir = File(ctx.cacheDir, "share")
        dir.mkdirs()
        val name = "scripts_" + SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val f = File(dir, name)
        f.writeText(text)
        return f
    }
}
