package com.rbxbot.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors

data class Hit(val video: Video, val links: List<String>)

object Scraper {
    /** 설정과 상관없이 항상 차단하는 링크 */
    private val BLOCKED = listOf("www.roblox.com", "whatsapp.com")

    /** 이 글자가 들어간 링크만 가져옴 */
    private val ALLOW = listOf("rekonise.com", "link-center", "linkvertise.com", "pastebin.com", "script", "pastefy")

    private val urlRe = Regex("""https?://[^\s<>"'`]+""")

    /** 검색어 + 확장 검색어로 최대 maxVideos개까지 모음 (API 1회는 약 50개) */
    fun searchAll(ctx: Context, query: String): List<Video> {
        val max = Prefs.i(ctx, "maxVideos").coerceIn(1, 500)
        val qs = ArrayList<String>()
        qs.add(query)
        for (s in Prefs.list(ctx, "expand")) {
            if (!query.contains(s, ignoreCase = true)) qs.add("$query $s")
        }
        val seen = LinkedHashMap<String, Video>()
        for (q in qs) {
            for (v in Api.search(q)) {
                if (seen.size >= max) break
                if (!seen.containsKey(v.id)) seen[v.id] = v
            }
            if (seen.size >= max) break
        }
        return seen.values.toList()
    }

    fun collect(ctx: Context, videos: List<Video>): List<Hit> {
        val kws = Prefs.list(ctx, "keyword")
        val ex = Prefs.list(ctx, "exclude").map { it.lowercase() }
        val ownerOnly = Prefs.b(ctx, "ownerOnly")
        val pool = Executors.newFixedThreadPool(Prefs.i(ctx, "threads").coerceIn(1, 16))
        try {
            val futures = videos.map { v -> pool.submit(Callable<Hit?> { analyze(v, kws, ex, ownerOnly) }) }
            val out = ArrayList<Hit>()
            for (f in futures) {
                try {
                    val h = f.get()
                    if (h != null) out.add(h)
                } catch (e: Exception) {
                    // 이 영상은 건너뜀
                }
            }
            return out
        } finally {
            pool.shutdown()
        }
    }

    private fun analyze(v: Video, kws: List<String>, ex: List<String>, ownerOnly: Boolean): Hit? {
        val d = Api.video(v.id) ?: return null
        // 영상(제목/설명)에 감지 단어(script)가 있어야 함 (대소문자 무시)
        if (kws.isNotEmpty() && kws.none { v.title.contains(it, true) || d.description.contains(it, true) }) return null
        val links = LinkedHashSet<String>()
        fun scan(t: String) {
            links.addAll(extract(t, ex))
        }
        scan(d.description)
        for (c in d.comments) {
            if (!ownerOnly || isOwner(c.author, v.channel)) scan(c.body)
        }
        return if (links.isEmpty()) null else Hit(v, links.toList())
    }

    private fun extract(t: String, ex: List<String>): List<String> =
        urlRe.findAll(t)
            .map { it.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>') }
            .filter { u ->
                val l = u.lowercase()
                ALLOW.any { l.contains(it) } && BLOCKED.none { l.contains(it) } && ex.none { l.contains(it) }
            }
            .toList()

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun isOwner(author: String, channel: String): Boolean {
        val a = norm(author)
        val c = norm(channel)
        if (a.isEmpty() || c.isEmpty()) return false
        if (a == c) return true
        return a.length >= 3 && c.length >= 3 && (a.contains(c) || c.contains(a))
    }

    fun uniqueLinks(hits: List<Hit>): List<String> {
        val all = LinkedHashSet<String>()
        hits.forEach { all.addAll(it.links) }
        return all.toList()
    }

    fun reportText(query: String, total: Int, hits: List<Hit>): String {
        val all = uniqueLinks(hits)
        val idx = all.withIndex().associate { it.value to it.index + 1 }
        val L = ArrayList<String>()
        L.add("━━━━━━━━━━━━━━━━━━━━")
        L.add("  $query  스크립트 & 링크")
        L.add("━━━━━━━━━━━━━━━━━━━━")
        L.add("검사한 영상 ${total}개  ·  링크 나온 영상 ${hits.size}개  ·  링크 ${all.size}개")
        L.add("")
        L.add("■ 전체 링크")
        all.forEachIndexed { i, u -> L.add("[${i + 1}] $u") }
        L.add("")
        L.add("■ 영상별")
        for (h in hits) {
            L.add("")
            L.add("▶ ${h.video.title}  (${h.video.channel})")
            L.add("   https://youtu.be/${h.video.id}")
            h.links.forEach { L.add("   └ [${idx[it]}] $it") }
        }
        L.add("")
        L.add("━━━━━━━━━━━━━━━━━━━━")
        return L.joinToString("\n") { if (it.isEmpty()) "|" else "| $it" }
    }

    fun report(ctx: Context, query: String, total: Int, hits: List<Hit>): File {
        val text = reportText(query, total, hits)
        val dir = File(ctx.cacheDir, "share")
        dir.mkdirs()
        val name = "scripts_" + SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val f = File(dir, name)
        f.writeText(text)
        return f
    }
}
