package com.rbxbot.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors

data class Hit(val video: Video, val links: List<String>)

object Scraper {
    private val urlRe = Regex("""https?://[^\s<>"'`]+""")

    /** 검색어 + 확장 검색어로 최대 maxVideos개까지 모음 (API 1회는 약 50개) */
    fun searchAll(ctx: Context, query: String): List<Video> {
        val max = Prefs.i(ctx, "maxVideos").coerceIn(1, 500)
        val qs = ArrayList<String>()
        qs.add(query)
        for (s in Prefs.list(ctx, "expand")) {
            if (!query.contains(s, ignoreCase = true)) qs.add("$query $s")
        }
        val seen = LinkedHashMap<String, Video>()
        for (q in qs) {
            for (v in Api.search(q)) {
                if (seen.size >= max) break
                if (!seen.containsKey(v.id)) seen[v.id] = v
            }
            if (seen.size >= max) break
        }
        return seen.values.toList()
    }

    fun collect(ctx: Context, videos: List<Video>): List<Hit> {
        val kws = Prefs.list(ctx, "keyword")
        val ex = Prefs.list(ctx, "exclude").map { it.lowercase() }
        val ownerOnly = Prefs.b(ctx, "ownerOnly")
        val pool = Executors.newFixedThreadPool(Prefs.i(ctx, "threads").coerceIn(1, 16))
        try {
            val futures = videos.map { v -> pool.submit(Callable<Hit?> { analyze(v, kws, ex, ownerOnly) }) }
            val out = ArrayList<Hit>()
            for (f in futures) {
                try {
                    val h = f.get()
                    if (h != null) out.add(h)
                } catch (e: Exception) {
                    // 이 영상은 건너뜀
                }
            }
            return out
        } finally {
            pool.shutdown()
        }
    }

    private fun analyze(v: Video, kws: List<String>, ex: List<String>, ownerOnly: Boolean): Hit? {
        val d = Api.video(v.id) ?: return null
        val links = LinkedHashSet<String>()
        fun scan(t: String) {
            if (kws.any { t.contains(it, ignoreCase = true) }) links.addAll(extract(t, ex))
        }
        scan(d.description)
        for (c in d.comments) {
            if (!ownerOnly || isOwner(c.author, v.channel)) scan(c.body)
        }
        return if (links.isEmpty()) null else Hit(v, links.toList())
    }

    private fun extract(t: String, ex: List<String>): List<String> =
        urlRe.findAll(t)
            .map { it.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>') }
            .filter { u ->
                val l = u.lowercase()
                ex.none { l.contains(it) }
            }
            .toList()

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun isOwner(author: String, channel: String): Boolean {
        val a = norm(author)
        val c = norm(channel)
        if (a.isEmpty() || c.isEmpty()) return false
        if (a == c) return true
        return a.length >= 3 && c.length >= 3 && (a.contains(c) || c.contains(a))
    }

    fun uniqueLinks(hits: List<Hit>): List<String> {
        val all = LinkedHashSet<String>()
        hits.forEach { all.addAll(it.links) }
        return all.toList()
    }

    fun report(ctx: Context, query: String, total: Int, hits: List<Hit>): File {
        val all = uniqueLinks(hits)
        val sb = StringBuilder()
        sb.append("검색어: ").append(query).append('\n')
        sb.append("검사한 영상: ${total}개 / 링크 발견 영상: ${hits.size}개 / 고유 링크: ${all.size}개\n\n")
        sb.append("===== 링크 목록 =====\n")
        all.forEach { sb.append(it).append('\n') }
        if (Prefs.b(ctx, "includeInfo")) {
            sb.append("\n===== 영상별 =====\n")
            for (h in hits) {
                sb.append('\n').append('[').append(h.video.title).append("] - ").append(h.video.channel).append('\n')
                sb.append("https://youtu.be/").append(h.video.id).append('\n')
                h.links.forEach { sb.append("  ").append(it).append('\n') }
            }
        }
        val dir = File(ctx.cacheDir, "share")
        dir.mkdirs()
        val name = "scripts_" + SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val f = File(dir, name)
        f.writeText(sb.toString())
        return f
    }
}
