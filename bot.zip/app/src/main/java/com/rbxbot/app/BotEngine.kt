package com.rbxbot.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

object BotEngine {
    private val busy = ConcurrentHashMap.newKeySet<String>()
    private val recent = ConcurrentHashMap<String, Long>()

    /** src: "noti"(알림) / "acc"(화면 읽기) / "input"(내가 입력창에서 보낸 것) */
    fun onMessage(ctx: Context, room: String, raw: String, src: String) {
        val t0 = raw.replace('\u00a0', ' ').replace("\u200b", "").trim()
        if (t0.isEmpty()) return
        Status.lastMsg = System.currentTimeMillis()
        if (src == "noti") L.d(ctx, "메시지[noti] 방='${L.cut(room)}' 내용='${L.cut(t0, 60)}'")
        if (!Prefs.b(ctx, "enabled")) {
            L.d(ctx, "봇이 꺼져 있어요 (설정)")
            return
        }

        // "홍길동 : !RSS 검색어" 처럼 앞에 이름이 붙어도 인식
        val cands = ArrayList<String>()
        cands.add(t0)
        if (t0.contains(" : ")) cands.add(t0.substringAfter(" : ").trim())
        var t = t0
        var k = 0
        for (c in cands) {
            val kk = kind(ctx, room, c)
            if (kk != 0) {
                t = c
                k = kk
                break
            }
        }
        if (k == 0) return

        val key = t
        val now = SystemClock.elapsedRealtime()
        val last = recent[key]
        if (last != null && now - last < 15000) {
            L.d(ctx, "중복이라 무시[$src] '${L.cut(t)}'")
            return
        }
        recent[key] = now
        L.d(ctx, "명령 인식[$src] 종류=$k 방='${L.cut(room)}' 내용='${L.cut(t, 60)}'")

        when (k) {
            1 -> {
                val svc = KakaoAccessibilityService.inst
                if (svc != null) {
                    svc.showPanel()
                    L.d(ctx, "플로팅 설정창 열기 요청함")
                } else {
                    Handler(Looper.getMainLooper()).post {
                        try {
                            val i = Intent(ctx, SettingsActivity::class.java)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i)
                            L.d(ctx, "설정창(전체화면) 열기 요청함")
                        } catch (e: Exception) {
                            L.d(ctx, "설정창 열기 실패: $e")
                        }
                    }
                }
            }
            2 -> {
                val trig = Prefs.s(ctx, "trigger").trim()
                val q = t.substring(trig.length).trim()
                if (q.isEmpty()) L.d(ctx, "검색어가 비어 있어요") else startSearch(ctx, room, q, src)
            }
        }
    }

    /** 0 없음 / 1 설정 / 2 검색 / 3 확인응답 */
    private fun kind(ctx: Context, room: String, t: String): Int {
        val trig = Prefs.s(ctx, "trigger").trim()
        val setCmd = Prefs.s(ctx, "settingsCmd").trim()
        if (setCmd.isNotEmpty() && t == setCmd) return 1
        if (trig.isNotEmpty() && t.startsWith(trig, ignoreCase = true) &&
            (t.length == trig.length || t[trig.length].isWhitespace())
        ) return 2
        return 0
    }

    private fun startSearch(ctx: Context, room: String, q: String, src: String) {
        if (!busy.add(room)) {
            L.d(ctx, "이 방은 이미 작업 중이라 무시")
            return
        }
        Thread {
            try {
                val videos = Scraper.searchAll(ctx, q)
                L.d(ctx, "검색 완료: 영상 ${videos.size}개")
                if (videos.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 로 찾은 영상이 없어요 ㅠㅠ", src)
                    return@Thread
                }
                val hits = Scraper.collect(ctx, videos)
                L.d(ctx, "수집 완료: 링크 발견 영상 ${hits.size}개")
                if (hits.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 스크립트 링크를 찾지 못했어요 ㅠㅠ", src)
                    return@Thread
                }
                val file = Scraper.report(ctx, q, videos.size, hits)
                // 한 번에: 파일 하나로 전송 (요약은 파일 맨 위에 들어있음). 실패하면 한 번 더 시도, 그래도 안 되면 텍스트로
                var sent = Kakao.sendFile(ctx, room, file, src)
                if (!sent) {
                    L.d(ctx, "파일 전송 실패, 재시도")
                    Thread.sleep(1500)
                    sent = Kakao.sendFile(ctx, room, file, src)
                }
                if (!sent) {
                    val links = Scraper.uniqueLinks(hits)
                    val text = "${hits.size}개 영상에서 링크 ${links.size}개를 찾았어요!\n" + links.joinToString("\n")
                    Kakao.sendText(ctx, room, text.take(3500), src)
                }
            } catch (e: Exception) {
                L.d(ctx, "검색 작업 오류: $e")
            } finally {
                busy.remove(room)
            }
        }.start()
    }
}
