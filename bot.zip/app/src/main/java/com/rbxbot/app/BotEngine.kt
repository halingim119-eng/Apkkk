package com.rbxbot.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

object BotEngine {
    private class Pending(val query: String, val videos: List<Video>, val expires: Long)

    private val pending = ConcurrentHashMap<String, Pending>()
    private val busy = ConcurrentHashMap.newKeySet<String>()
    private val recent = ConcurrentHashMap<String, Long>()

    /** src: "noti"(알림) / "acc"(화면 읽기) / "input"(내가 입력창에서 보낸 것) */
    fun onMessage(ctx: Context, room: String, raw: String, src: String) {
        val t0 = raw.replace('\u00a0', ' ').replace("\u200b", "").trim()
        if (t0.isEmpty()) return
        Status.lastMsg = System.currentTimeMillis()
        if (src == "noti") L.d(ctx, "메시지[noti] 방='${L.cut(room)}' 내용='${L.cut(t0, 60)}'")
        if (!Prefs.b(ctx, "enabled")) {
            L.d(ctx, "봇이 꺼져 있어요 (설정)")
            return
        }

        // "홍길동 : !RSS 검색어" 처럼 앞에 이름이 붙어도 인식
        val cands = ArrayList<String>()
        cands.add(t0)
        if (t0.contains(" : ")) cands.add(t0.substringAfter(" : ").trim())
        var t = t0
        var k = 0
        for (c in cands) {
            val kk = kind(ctx, room, c)
            if (kk != 0) {
                t = c
                k = kk
                break
            }
        }
        if (k == 0) return

        val key = if (k == 3) "$room|$t" else t
        val now = SystemClock.elapsedRealtime()
        val last = recent[key]
        if (last != null && now - last < 15000) {
            L.d(ctx, "중복이라 무시[$src] '${L.cut(t)}'")
            return
        }
        recent[key] = now
        L.d(ctx, "명령 인식[$src] 종류=$k 방='${L.cut(room)}' 내용='${L.cut(t, 60)}'")

        when (k) {
            1 -> {
                val svc = KakaoAccessibilityService.inst
                if (svc != null) {
                    svc.showPanel()
                    L.d(ctx, "플로팅 설정창 열기 요청함")
                } else {
                    Handler(Looper.getMainLooper()).post {
                        try {
                            val i = Intent(ctx, SettingsActivity::class.java)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i)
                            L.d(ctx, "설정창(전체화면) 열기 요청함")
                        } catch (e: Exception) {
                            L.d(ctx, "설정창 열기 실패: $e")
                        }
                    }
                }
            }
            2 -> {
                val trig = Prefs.s(ctx, "trigger").trim()
                val q = t.substring(trig.length).trim()
                if (q.isEmpty()) L.d(ctx, "검색어가 비어 있어요") else startSearch(ctx, room, q, src)
            }
            3 -> {
                val pk = findPending(room)
                val p = if (pk != null) pending.remove(pk) else null
                if (p == null) return
                if (SystemClock.elapsedRealtime() >= p.expires) {
                    L.d(ctx, "응답 시간이 지나서 무시")
                    return
                }
                startCollect(ctx, room, p, src)
            }
        }
    }

    /** 0 없음 / 1 설정 / 2 검색 / 3 확인응답 */
    private fun kind(ctx: Context, room: String, t: String): Int {
        val trig = Prefs.s(ctx, "trigger").trim()
        val setCmd = Prefs.s(ctx, "settingsCmd").trim()
        if (setCmd.isNotEmpty() && t == setCmd) return 1
        if (trig.isNotEmpty() && t.startsWith(trig, ignoreCase = true) &&
            (t.length == trig.length || t[trig.length].isWhitespace())
        ) return 2
        if (findPending(room) != null && looksYes(ctx, t)) return 3
        return 0
    }

    private fun findPending(room: String): String? {
        if (pending.containsKey(room)) return room
        if (room.isEmpty()) return pending.keys.firstOrNull()
        return pending.keys.firstOrNull { it.isNotEmpty() && (it.contains(room) || room.contains(it)) }
    }

    private fun looksYes(ctx: Context, t: String): Boolean {
        val n = t.filter { it.isLetterOrDigit() }
        if (n.isEmpty()) return false
        return Prefs.list(ctx, "yes").any { w -> n == w || n.replace(w, "").isEmpty() }
    }

    private fun startSearch(ctx: Context, room: String, q: String, src: String) {
        if (!busy.add(room)) {
            L.d(ctx, "이 방은 이미 작업 중이라 무시")
            return
        }
        Thread {
            try {
                val t0 = SystemClock.elapsedRealtime()
                val ref = AtomicReference<ByteArray?>()
                // 배너는 병렬로 받고, 3초 안에 못 받으면 배너 없이 진행
                val bt = Thread {
                    val b = Api.banner(q)
                    val el = SystemClock.elapsedRealtime() - t0
                    if (b != null && el <= 3000) ref.set(b)
                    L.d(ctx, "배너 ${if (b != null) "도착" else "실패"} (${el}ms)")
                }
                bt.start()

                val videos = Scraper.searchAll(ctx, q)
                L.d(ctx, "검색 완료: 영상 ${videos.size}개")

                val remain = 3000 - (SystemClock.elapsedRealtime() - t0)
                if (remain > 0) bt.join(remain)
                val svg = ref.get()

                if (svg != null) {
                    val png = BannerRenderer.render(ctx, svg)
                    L.d(ctx, "배너 PNG 변환 ${if (png != null) "성공" else "실패"}")
                    val sent = if (png != null) Kakao.sendImage(ctx, room, png, src) else false
                    if (!sent) Kakao.sendText(ctx, room, "${Api.BASE}/api/banner?q=${Api.enc(q)}", src)
                } else {
                    L.d(ctx, "배너를 3초 안에 못 받아서 배너 없이 진행")
                }

                if (videos.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 로 찾은 영상이 없어요 ㅠㅠ", src)
                    return@Thread
                }
                pending[room] = Pending(q, videos, SystemClock.elapsedRealtime() + Prefs.i(ctx, "waitSec") * 1000L)
                Kakao.sendText(
                    ctx, room,
                    "${videos.size}개의 영상을 찾았어요, \"$q\" 를 원하시는 게\n맞으시면 스크립트를 찾아올게요 :P\n응 이나 네 로 대답하면 찾아올게요!",
                    src
                )
            } catch (e: Exception) {
                L.d(ctx, "검색 작업 오류: $e")
            } finally {
                busy.remove(room)
            }
        }.start()
    }

    private fun startCollect(ctx: Context, room: String, p: Pending, src: String) {
        if (!busy.add(room)) {
            L.d(ctx, "이 방은 이미 작업 중이라 무시")
            return
        }
        Thread {
            try {
                Kakao.sendText(ctx, room, "${p.videos.size}개 영상의 설명란이랑 댓글을 뒤지는 중이에요! 잠깐만요 :)", src)
                val hits = Scraper.collect(ctx, p.videos)
                L.d(ctx, "수집 완료: 링크 발견 영상 ${hits.size}개")
                if (hits.isEmpty()) {
                    Kakao.sendText(ctx, room, "스크립트 링크를 찾지 못했어요 ㅠㅠ", src)
                    return@Thread
                }
                val file = Scraper.report(ctx, p.query, p.videos.size, hits)
                val n = Scraper.uniqueLinks(hits).size
                Kakao.sendFile(ctx, room, file, src)
                Kakao.sendText(ctx, room, "${hits.size}개 영상에서 링크 ${n}개를 찾았어요! 파일로 정리했어요 :)", src)
            } catch (e: Exception) {
                L.d(ctx, "수집 작업 오류: $e")
            } finally {
                busy.remove(room)
            }
        }.start()
    }
}
