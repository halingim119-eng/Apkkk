package com.rbxbot.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

object BotEngine {
    private class Pending(val query: String, val videos: List<Video>, val expires: Long)

    private val pending = ConcurrentHashMap<String, Pending>()
    private val busy = ConcurrentHashMap.newKeySet<String>()
    private val recent = ConcurrentHashMap<String, Long>()

    /** 알림/화면에서 감지한 메시지가 여기로 들어옴 */
    fun onMessage(ctx: Context, room: String, raw: String, src: String) {
        if (!Prefs.b(ctx, "enabled")) return
        val t = raw.trim()
        if (t.isEmpty()) return

        val trig = Prefs.s(ctx, "trigger").trim()
        val setCmd = Prefs.s(ctx, "settingsCmd").trim()
        val isSet = setCmd.isNotEmpty() && t == setCmd
        val isTrig = trig.isNotEmpty() && t.startsWith(trig, ignoreCase = true) &&
            (t.length == trig.length || t[trig.length].isWhitespace())
        val isYes = pending.containsKey(room) && looksYes(ctx, t)
        if (!isSet && !isTrig && !isYes) return

        // 알림+화면으로 같은 메시지가 두 번 들어오는 것 방지
        val key = if (isYes) "$room|$t" else t
        val now = SystemClock.elapsedRealtime()
        val last = recent[key]
        if (last != null && now - last < 15000) return
        recent[key] = now

        when {
            isSet -> Handler(Looper.getMainLooper()).post {
                try {
                    val i = Intent(ctx, SettingsActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                } catch (e: Exception) { }
            }
            isTrig -> {
                val q = t.substring(trig.length).trim()
                if (q.isNotEmpty()) startSearch(ctx, room, q, src)
            }
            isYes -> {
                val p = pending.remove(room)
                if (p != null && SystemClock.elapsedRealtime() < p.expires) startCollect(ctx, room, p, src)
            }
        }
    }

    private fun looksYes(ctx: Context, t: String): Boolean {
        val n = t.filter { it.isLetterOrDigit() }
        if (n.isEmpty()) return false
        return Prefs.list(ctx, "yes").any { w -> n == w || n.replace(w, "").isEmpty() }
    }

    private fun startSearch(ctx: Context, room: String, q: String, src: String) {
        if (!busy.add(room)) return
        Thread {
            try {
                // 배너가 안 오면 아무 메시지도 안 보냄
                val svg = Api.banner(q) ?: return@Thread
                val videos = Scraper.searchAll(ctx, q)

                val png = BannerRenderer.render(ctx, svg)
                val sent = if (png != null) Kakao.sendImage(ctx, room, png, src) else false
                if (!sent) Kakao.sendText(ctx, room, "${Api.BASE}/api/banner?q=${Api.enc(q)}", src)

                if (videos.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 로 찾은 영상이 없어요 ㅠㅠ", src)
                    return@Thread
                }
                pending[room] = Pending(q, videos, SystemClock.elapsedRealtime() + Prefs.i(ctx, "waitSec") * 1000L)
                Kakao.sendText(
                    ctx, room,
                    "${videos.size}개의 영상을 찾았어요, \"$q\" 를 원하시는 게\n맞으시면 스크립트를 찾아올게요 :P\n응 이나 네 로 대답하면 찾아올게요!",
                    src
                )
            } catch (e: Exception) {
            } finally {
                busy.remove(room)
            }
        }.start()
    }

    private fun startCollect(ctx: Context, room: String, p: Pending, src: String) {
        if (!busy.add(room)) return
        Thread {
            try {
                Kakao.sendText(ctx, room, "${p.videos.size}개 영상의 설명란이랑 댓글을 뒤지는 중이에요! 잠깐만요 :)", src)
                val hits = Scraper.collect(ctx, p.videos)
                if (hits.isEmpty()) {
                    Kakao.sendText(ctx, room, "스크립트 링크를 찾지 못했어요 ㅠㅠ", src)
                    return@Thread
                }
                val file = Scraper.report(ctx, p.query, p.videos.size, hits)
                val n = Scraper.uniqueLinks(hits).size
                Kakao.sendFile(ctx, room, file, src)
                Kakao.sendText(ctx, room, "${hits.size}개 영상에서 링크 ${n}개를 찾았어요! 파일로 정리했어요 :)", src)
            } catch (e: Exception) {
            } finally {
                busy.remove(room)
            }
        }.start()
    }
}
