package com.rbxbot.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

object BotEngine {
    private val results = ConcurrentHashMap<String, List<String>>()
    private val dates = ConcurrentHashMap<String, Map<String, String>>()
    private val busy = ConcurrentHashMap.newKeySet<String>()
    private val recent = ConcurrentHashMap<String, Long>()

    /** src: "noti"(알림) / "acc"(화면 읽기) / "input"(내가 입력창에서 보낸 것) */
    fun onMessage(ctx: Context, room: String, raw: String, src: String) {
        val t0 = raw.replace('\u00a0', ' ').replace("\u200b", "").trim()
        if (t0.isEmpty()) return
        Status.lastMsg = System.currentTimeMillis()
        if (src == "noti") L.d(ctx, "메시지[noti] 방='${L.cut(room)}' 내용='${L.cut(t0, 60)}'")
        if (!Prefs.b(ctx, "enabled")) {
            L.d(ctx, "봇이 꺼져 있어요 (설정)")
            return
        }

        // "홍길동 : !RSS 검색어" 처럼 앞에 이름이 붙어도 인식
        val cands = ArrayList<String>()
        cands.add(t0)
        if (t0.contains(" : ")) cands.add(t0.substringAfter(" : ").trim())
        // 답장 메시지: 인용된 글 + 내 글이 같이 오므로 마지막 줄 / 마지막 ':' 뒤 / 맨 끝 숫자도 후보로
        if (t0.contains("답장") || t0.contains('\n')) {
            val lines = t0.lines().map { it.trim() }.filter { it.isNotEmpty() }
            lines.lastOrNull()?.let { cands.add(it) }
            lines.lastOrNull()?.let { l ->
                if (l.contains(" : ")) cands.add(l.substringAfterLast(" : ").trim())
                if (l.contains(":")) cands.add(l.substringAfterLast(":").trim())
            }
            Regex("(?:^|\\s)#?(\\d{1,3})\\s*번?\\s*$").find(t0)?.let { cands.add(it.groupValues[1]) }
            if (t0.contains("답장") && findResults(room) != null) L.d(ctx, "답장 메시지 후보: ${cands.map { L.cut(it, 20) }}")
        }
        var t = t0
        var k = 0
        for (c in cands) {
            val kk = kind(ctx, room, c)
            if (kk != 0) {
                t = c
                k = kk
                break
            }
        }
        if (k == 0) return

        val key = if (k == 3) "$room|$t" else t
        val now = SystemClock.elapsedRealtime()
        val last = recent[key]
        if (last != null && now - last < 15000) {
            L.d(ctx, "중복이라 무시[$src] '${L.cut(t)}'")
            return
        }
        recent[key] = now
        L.d(ctx, "명령 인식[$src] 종류=$k 방='${L.cut(room)}' 내용='${L.cut(t, 60)}'")

        when (k) {
            1 -> {
                val svc = KakaoAccessibilityService.inst
                if (svc != null) {
                    svc.showPanel()
                    L.d(ctx, "플로팅 설정창 열기 요청함")
                } else {
                    Handler(Looper.getMainLooper()).post {
                        try {
                            val i = Intent(ctx, SettingsActivity::class.java)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i)
                            L.d(ctx, "설정창(전체화면) 열기 요청함")
                        } catch (e: Exception) {
                            L.d(ctx, "설정창 열기 실패: $e")
                        }
                    }
                }
            }
            2 -> {
                val trig = Prefs.s(ctx, "trigger").trim()
                val q = t.substring(trig.length).trim()
                if (q.isEmpty()) L.d(ctx, "검색어가 비어 있어요") else startSearch(ctx, room, q, src)
            }
            3 -> startBypass(ctx, room, t, src)
        }
    }

    private fun findResults(room: String): List<String>? {
        results[room]?.let { return it }
        if (room.isEmpty()) return results.values.firstOrNull()
        return results.entries.firstOrNull { it.key.isNotEmpty() && (it.key.contains(room) || room.contains(it.key)) }?.value
    }

    private val numRe = Regex("^[#\\d,\\s번.]+$")

    private fun startBypass(ctx: Context, room: String, t: String, src: String) {
        val links = findResults(room) ?: return
        val nums = Regex("\\d+").findAll(t).map { it.value.toIntOrNull() ?: 0 }.distinct().take(5).toList()
        for (n in nums) {
            if (n < 1 || n > links.size) {
                Kakao.sendText(ctx, room, "| ${n}번 링크는 없어요 (1~${links.size}번까지 있어요)", src)
                continue
            }
            val link = links[n - 1]
            Thread {
                try {
                    Kakao.sendText(ctx, room, "| 바이패스 중이에요 :p\n1분 이상 걸려요!", src)
                    val (out, err) = Api.bypassChain(ctx, link)
                    val d = dates[room]?.get(link).orEmpty()
                    if (out != null) Kakao.sendText(ctx, room, if (d.isNotEmpty()) "$out ($d)" else out, src)
                    else Kakao.sendText(ctx, room, "| ${err ?: "알 수 없는 오류"}", src)
                } catch (e: Exception) {
                    Kakao.sendText(ctx, room, "| 오류: $e", src)
                }
            }.start()
        }
    }

    /** 0 없음 / 1 설정 / 2 검색 / 3 확인응답 */
    private fun kind(ctx: Context, room: String, t: String): Int {
        val trig = Prefs.s(ctx, "trigger").trim()
        val setCmd = Prefs.s(ctx, "settingsCmd").trim()
        if (setCmd.isNotEmpty() && t == setCmd) return 1
        if (trig.isNotEmpty() && t.startsWith(trig, ignoreCase = true) &&
            (t.length == trig.length || t[trig.length].isWhitespace())
        ) return 2
        if (numRe.containsMatchIn(t) && t.any { it.isDigit() } && findResults(room) != null) return 3
        return 0
    }

    private fun startSearch(ctx: Context, room: String, q: String, src: String) {
        if (!busy.add(room)) {
            L.d(ctx, "이 방은 이미 작업 중이라 무시")
            return
        }
        Thread {
            try {
                val videos = Scraper.searchAll(ctx, q)
                L.d(ctx, "검색 완료: 영상 ${videos.size}개")
                if (videos.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 로 찾은 영상이 없어요 ㅠㅠ", src)
                    return@Thread
                }
                val hits = Scraper.collect(ctx, videos)
                L.d(ctx, "수집 완료: 링크 발견 영상 ${hits.size}개")
                if (hits.isEmpty()) {
                    Kakao.sendText(ctx, room, "\"$q\" 스크립트 링크를 찾지 못했어요 ㅠㅠ", src)
                    return@Thread
                }
                // Pastefy에 올리고 raw 링크를 한 번에 전송
                val title = "| $q 스크립트&링크"
                val text = Scraper.reportText(q, videos.size, hits)
                var raw: String? = null
                for (n in 1..3) {
                    raw = Api.paste(Prefs.s(ctx, "pastefyKey").trim(), title, text)
                    if (raw != null) break
                    L.d(ctx, "Pastefy 업로드 실패, 재시도 $n")
                    Thread.sleep(1500)
                }
                if (raw != null) {
                    Prefs.put(ctx, "lastRaw", raw)
                    L.d(ctx, "Pastefy 업로드 성공: $raw")
                    val links = Scraper.uniqueLinks(hits)
                    results[room] = links
                    dates[room] = Scraper.linkDates(hits)
                    Kakao.sendText(
                        ctx, room,
                        "| ${videos.size}개의 영상에서 ${links.size}개의 링크를 찾았어요 :p\n" +
                            "$raw 에 정리해 놓았고, 바이패스로 편하게 얻고 싶으시면\n메세지에 답장을 해 링크 번호를 말해주세요",
                        src
                    )
                } else {
                    // 업로드가 끝내 안 되면 예전처럼 파일로
                    L.d(ctx, "Pastefy 실패 → 파일로 전송")
                    Kakao.sendFile(ctx, room, Scraper.report(ctx, q, videos.size, hits), src)
                }
            } catch (e: Exception) {
                L.d(ctx, "검색 작업 오류: $e")
            } finally {
                busy.remove(room)
            }
        }.start()
    }
}
