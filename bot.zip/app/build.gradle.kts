plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 버전은 항상 올라가게 (빌드 시각 기준, 분 단위) → 덮어 설치(업데이트) 때 낮은 버전 충돌 안 남
val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
val stamp = (System.currentTimeMillis() / 60000L).toInt()

android {
    namespace = "com.rbxbot.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rbxbot.app"
        minSdk = 26
        targetSdk = 34
        versionCode = stamp
        versionName = "1.$run.$stamp"
    }

    // 항상 같은 키로 서명 → 업데이트할 때 패키지 충돌 안 남
    signingConfigs {
        create("bot") {
            storeFile = file("bot.keystore")
            storePassword = "botbot123"
            keyAlias = "bot"
            keyPassword = "botbot123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("bot") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("bot")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
